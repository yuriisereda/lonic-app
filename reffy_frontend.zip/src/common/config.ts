// export const apiKeyForMap = "AIzaSyD2D8SdvNGJPUQQkRHLnu6gGVeQSg5MeRM";
export const apiKeyForMap = "AIzaSyDGB87-9ktVmvmwFw4kcR9bNHmuNRQlpL4";
export const config = {
    // hostAddress: "http://localhost:5000/",
    hostAddress: "https://reffy-backend-v1.herokuapp.com/",
};

export const oneSignalAppID = "ac5d0a61-77f4-4c17-a914-6ed7ecebe17a";
export const oneSignalRestAPIKey = "ZjEzMjBlOTUtNTBmYS00MGJjLTg3YmMtNmE1YTM5Mzk3ZmE3";
export const androidIDForOneSignal = "914979778334";
// Your One signal App ID: ac5d0a61-77f4-4c17-a914-6ed7ecebe17a
// one signal rest api key: ZjEzMjBlOTUtNTBmYS00MGJjLTg3YmMtNmE1YTM5Mzk3ZmE3