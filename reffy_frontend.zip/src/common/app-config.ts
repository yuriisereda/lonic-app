export const appConfig = {
    uploadImageWidth: 300,
    uploadImageHeight: 300,
};