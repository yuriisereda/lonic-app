export const playForms = [
	{
		id: "1",
		title: "3 vs 3"
	},
	{
		id: "2",
		title: "5 vs 5"
	},
	{
		id: "3",
		title: "7 vs 7"
	},
	{
		id: "4",
		title: "9 vs 9"
	},
	{
		id: "5",
		title: "Futsal"
	},

	{
		id: "6",
		title: "11 vs 11"
	},
];
export const gameTypes = [
	{
		id: "1",
		title: "Exercise Game"
	},
	{
		id: "2",
		title: "Tournament"
	},
	{
		id: "3",
		title: "Friendship"
	}
];
export const APPLIED = 'applied';
export const HIRED = 'hired';
export const COACH = 'coach';
export const REFEREE = 'referee';
export const text = {
	noRatingText: "Game has no ratings yet",
	available: "Available",
	unavailable: "Not Available",
	rate_waiting: "Waiting to be rated",
	closed: "Closed"
};
