export const endPoints = {
  login: "user_login",
  register: "user_register",
  forgotPassword: "",
  games: "games_load",
  userLoad: "user_load",
  userUpdate: "user_update",
  createGame: "game_new",
  gameLoad: "game_load",
  applyAsReferee: "game_apply_as_referee",
  rateGame: "game_rate",
  hireReferee: "game_hire_referee",
};
