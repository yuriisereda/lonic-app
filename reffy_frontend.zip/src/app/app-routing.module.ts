import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'home',
    pathMatch: 'full'
  },
  {
    path: 'home',
    loadChildren: () => import('./pages/home/home.module').then(m => m.HomePageModule)
  },
  {
    path: 'login',
    loadChildren: () => import('./pages/login/login.module').then(m => m.LoginPageModule)
  },
  {
    path: 'register/:flag',
    loadChildren: () => import('./pages/register/register.module').then(m => m.RegisterPageModule)
  },
  {
    path: 'register-entry',
    loadChildren: () => import('./pages/register-entry/register-entry.module').then(m => m.RegisterEntryPageModule)
  },
  {
    path: 'games',
    loadChildren: () => import('./pages/games/games.module').then(m => m.GamesPageModule)
  },
  {
    path: 'create-game',
    loadChildren: () => import('./pages/create-game/create-game.module').then(m => m.CreateGamePageModule)
  },
  {
    path: 'game-details/:game_id',
    loadChildren: () => import('./pages/game-details/game-details.module').then(m => m.GameDetailsPageModule)
  },
  {
    path: 'user-detail/:user_id',
    loadChildren: () => import('./pages/user-detail/user-detail.module').then(m => m.UserDetailPageModule)
  },
  {
    path: 'rate-game/:game_id',
    loadChildren: () => import('./pages/rate-game/rate-game.module').then(m => m.RateGamePageModule)
  },
  {
    path: 'confirmation',
    loadChildren: () => import('./pages/confirmation/confirmation.module').then(m => m.ConfirmationPageModule)
  },
  {
    path: 'profile',
    loadChildren: () => import('./pages/profile/profile.module').then(m => m.ProfilePageModule)
  }
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
