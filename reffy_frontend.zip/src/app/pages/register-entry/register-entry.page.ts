import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-register-entry',
  templateUrl: './register-entry.page.html',
  styleUrls: ['./register-entry.page.scss'],
})
export class RegisterEntryPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
