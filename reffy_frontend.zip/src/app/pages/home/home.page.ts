import { Component } from '@angular/core';
import { MenuController } from '@ionic/angular';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {
  lang:any;
  
  constructor(
    private menu: MenuController,
    public translate: TranslateService
  ) {
    this.lang = 'ta';
    this.translate.setDefaultLang('ta');
    this.translate.use('ta');
  }
  
  switchLanguage() {
    this.translate.use(this.lang);
  }
}
