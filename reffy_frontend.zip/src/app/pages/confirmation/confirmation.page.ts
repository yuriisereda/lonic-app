import { Component, OnInit } from '@angular/core';
import {MenuController, NavController} from '@ionic/angular';

@Component({
  selector: 'app-confirmation',
  templateUrl: './confirmation.page.html',
  styleUrls: ['./confirmation.page.scss'],
})
export class ConfirmationPage implements OnInit {

  constructor(
    private navCtrl: NavController,
    private menuCtrl: MenuController,
  ) { }

  ngOnInit() {
  }

  goBack() {
    this.navCtrl.back();
  }

  openMenu() {
    this.menuCtrl.enable(true, 'first');
    this.menuCtrl.open('first');
  }
}
