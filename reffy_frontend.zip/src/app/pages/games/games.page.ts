import { Component, OnInit } from '@angular/core';
import { MenuController } from '@ionic/angular';
import {GeneralService} from '../../services/general/general.service';
import { GameCardType } from '../../models';
import {HIRED, playForms} from '../../../common/constants';
import { GameService } from '../../services/game/game.service';
import { COACH, REFEREE } from '../../../common/constants';
import * as moment from 'moment'

@Component({
  selector: 'app-games',
  templateUrl: './games.page.html',
  styleUrls: ['./games.page.scss'],
})
export class GamesPage implements OnInit {
  isLoading: boolean = false;
  viewMode: boolean = false; // if true my games, else all games
  allGames: GameCardType[] = null;
  isCoach: boolean = false;
  user_id: number = Number(localStorage.getItem('user_id'));
  availableGames: GameCardType[] = null;
  unAvailableGames: GameCardType[] = null;

  constructor(
    private menu: MenuController,
    private gameService: GameService,
    private generalService: GeneralService,
  ) {

  }

  ngOnInit() {
    this.setViewMode(false);
  }

  ionViewWillEnter() {
    const type = localStorage.getItem('type');
    this.isCoach = (type === COACH);
    // TODO load games
    this.loadGames();
  }

  openMenu() {
    this.menu.enable(true, 'first');
    this.menu.open('first');
  }

  /**
   * @param mode: if true show my games, else show all games
   */
  setViewMode(mode) {
    this.viewMode = mode;
    this.extractGames();
  }

  /**
   * @description pull games from server
   */
  loadGames() {
    this.isLoading = true;
    this.gameService.fetchGames(this.user_id).subscribe(
      res => {
        this.isLoading = false;
        const games = res;
        games.map(game => {
          const playForm =  playForms.find(item => item.id === game.play_form);
          game.play_form = playForm && playForm.title;
        });
        this.allGames = games;
        this.extractGames();
        console.log(this.allGames);
      },
      error => {
        this.isLoading = false;
        this.generalService.presentToast(
          error.message && error.message.length
            ? error.message
            : "Network Problem. Please try again after sometimes",
          "danger"
        );
      }
    );
  }

  /**
   * @description filter games by start_time is before now | This is available games for coach
   */
  getUnPlayedGames() {
    const data = this.allGames && JSON.parse(JSON.stringify(this.allGames));
    const unPlayedGames = data && data.filter(game => {
      return moment(game.start_time).isAfter(moment().utc());
    });

    return this.sortGamesByStartTime(unPlayedGames);
  }

  /**
   * @description filter unPlayedGames by coach is me
   */
  getUnPlayedGamesForMe() {
    const unPlayedGames = this.getUnPlayedGames();
    const data = unPlayedGames && JSON.parse(JSON.stringify(unPlayedGames));
    const unPlayedGamesForMe = data && data.filter(game => (game.coach && game.coach.id) === this.user_id);

    return this.sortGamesByStartTime(unPlayedGamesForMe);
  }

  /**
   * @description filter games by start_time is over now | This is unavailable games for referee
   */
  getPlayedGames() {
    const data = this.allGames && JSON.parse(JSON.stringify(this.allGames));
    const playedGames = data && data.filter(game => {
      return moment(game.start_time).isBefore(moment().utc());
    });

    return this.sortGamesByStartTime(playedGames);
  }

  /**
   * @description filter playedGames by coach is me
   */
  getPlayedGamesForMe() {
    const playedGames = this.getPlayedGames();
    const data = playedGames && JSON.parse(JSON.stringify(playedGames));
    const playedGamesForMe = data && data.filter(game => (game.coach && game.coach.id) === this.user_id);

    return this.sortGamesByStartTime(playedGamesForMe);
  }

  /**
   * @description for referee, filter the not played games by referee's playform
   */
  getMatchedGames() {
    const unPlayedGames = this.getUnPlayedGames();
    const data = unPlayedGames && JSON.parse(JSON.stringify(unPlayedGames));
    const matchedPlayFormIds = localStorage.getItem('matched_play_form');

    if (matchedPlayFormIds !== 'undefined' && matchedPlayFormIds.length > 0) {
      const playFormIds = matchedPlayFormIds.split(',');
      const playFormTitles = playFormIds && playFormIds.map(id => {
        const form = playForms.find(item => item.id === id);
        return form && form.title;
      });

      return data && data.filter(game => {
        const index = playFormTitles && playFormTitles.findIndex(item => item === (game && game.play_form));
        if (index !== -1) {
          return true;
        } else {
          return false;
        }
      });
    } else {
      return null;
    }
  }
  /**
   * @description for referee, filter the matched games if the game doesn't hire any referee yet.
   */
  getNoRefereeGames() {
    const matchedGames = this.getMatchedGames();
    const data = matchedGames && JSON.parse(JSON.stringify(matchedGames));
    const noRefereeGames = data && data.filter(game => {
      const index = game.referees.findIndex(item => item.status === HIRED);
      if (index !== -1) {
        return false;
      } else {
        return true;
      }
    });

    return this.sortGamesByStartTime(noRefereeGames);
  }

  /**
   * @description filter noRefereeGames by I've applied or been hired
   */
  getNoRefereeGamesForMe() {
    const noRefereeGames = this.getNoRefereeGames();
    const data = noRefereeGames && JSON.parse(JSON.stringify(noRefereeGames));
    const noRefereeGamesForMe = data && data.filter(game => {
      const index = game.referees && game.referees.findIndex(referee => (referee.user && referee.user.id) === this.user_id);

      if (index !== -1) {
        return true;
      } else {
        return false;
      }
    });

    return this.sortGamesByStartTime(noRefereeGamesForMe);
  }

  /**
   *@description get unAvailable games for referee
   */
  getRefereeUnAvailableGames() {
    const noRefereeGames = this.getNoRefereeGames();
    // const matchedGames = this.getMatchedGames();
    const data = this.allGames && JSON.parse(JSON.stringify(this.allGames));
    const unAvailableGamesForReferee = data && data.filter(game => {
      const index = noRefereeGames && noRefereeGames.findIndex(item => item.id === game.id);
      if (index === -1) {
        return true;
      } else {
        return false;
      }
    });

    return this.sortGamesByStartTime(unAvailableGamesForReferee);
  }

  /**
   * @description filter refereeUnAvailableGames by I've applied or been hired
   */
  getRefereeUnAvailableGamesForMe() {
    const refereeUnAvailableGames = this.getRefereeUnAvailableGames();
    const data = refereeUnAvailableGames && JSON.parse(JSON.stringify(refereeUnAvailableGames));
    const refereeUnAvailableGamesForMe = data &&
      data.filter(
        game => (
          game.referees &&
          game.referees.findIndex(referee => (referee.user && referee.user.id) === this.user_id)
        ) !== -1
      );

    return this.sortGamesByStartTime(refereeUnAvailableGamesForMe);
  }

  sortGamesByStartTime(games) {
    return games && games.sort((game1, game2) => {
      if(moment(game1.start_time).isAfter(moment(game2.start_time))) {
        return 1;
      } else {
        return -1;
      }
    });
  }

  getMonthLabel(date) {
    return moment(date).format('MMMM');
  }

  getDayLabel(date) {
    return moment(date).format('DD');
  }

  extractGames() {
    if (this.viewMode) { // my games
      this.availableGames = this.isCoach ? this.getUnPlayedGamesForMe() : this.getNoRefereeGamesForMe();
      this.unAvailableGames = this.isCoach ? this.getPlayedGamesForMe() : this.getRefereeUnAvailableGamesForMe();
    } else { // all games
      this.availableGames = this.isCoach ? this.getUnPlayedGames() : this.getNoRefereeGames();
      this.unAvailableGames = this.isCoach ? this.getPlayedGames() : this.getRefereeUnAvailableGames();
    }
  }
}
