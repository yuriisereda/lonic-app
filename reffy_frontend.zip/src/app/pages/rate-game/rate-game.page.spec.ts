import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { RateGamePage } from './rate-game.page';

describe('RateGamePage', () => {
  let component: RateGamePage;
  let fixture: ComponentFixture<RateGamePage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RateGamePage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(RateGamePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
