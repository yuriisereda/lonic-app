import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { RateGamePageRoutingModule } from './rate-game-routing.module';

import { RateGamePage } from './rate-game.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    RateGamePageRoutingModule
  ],
  declarations: [RateGamePage]
})
export class RateGamePageModule {}
