import {Component, OnInit} from '@angular/core';
import {MenuController, NavController} from '@ionic/angular';
import {ActivatedRoute} from '@angular/router';
import {GameService} from '../../services/game/game.service';
import {GeneralService} from '../../services/general/general.service';

@Component({
	selector: 'app-rate-game',
	templateUrl: './rate-game.page.html',
	styleUrls: ['./rate-game.page.scss'],
})
export class RateGamePage implements OnInit {
	isSaving: boolean = false;
	isLoading: boolean = false;
	game_id: string;
	gameData: any;
	rate: number = 0;
	rates: number[] = [1, 2, 3, 4, 5];

	constructor(
		private actRoute: ActivatedRoute,
		private  navCtrl: NavController,
		private gameService: GameService,
		private generalService: GeneralService,
		private menuCtrl: MenuController,
	) {
		this.game_id = this.actRoute.snapshot.paramMap.get('game_id');
		this.loadGame();
	}

	ngOnInit() {
	}

	loadGame() {
		this.isLoading = true;
		this.gameService.fetchGame(this.game_id).subscribe(
			res => {
				this.isLoading = false;
				console.log(res);
				this.gameData = res;
			},
			error => {
				this.isLoading = false;
				this.generalService.presentToast(
					error.message ? error.message :
						"Network Problem. Please try later",
					"danger"
				);
				console.log(error);
			}
		);
	}

	openMenu() {
		this.menuCtrl.enable(true, 'first');
		this.menuCtrl.open('first');
	}

	goBack() {
		this.navCtrl.back();
	}

	onClickStar(n) {
		this.rate = n;
	}

	onClickRate() {
		if (this.rate === 0) {
			alert('Please select what you want to rate!')
		} else {
			const game_id = Number(this.game_id);
			const referee_id = localStorage.getItem('user_id');
			this.isSaving = true;
			this.gameService.rateGame(game_id, referee_id, this.rate).subscribe(
				res => {
					this.isSaving = false;
					this.generalService.presentToast(
						"Game rated successfully!",
						"primary"
					);
					this.goBack();
				},
				error => {
					this.isSaving = false;
					this.generalService.presentToast(
						error.message ? error.message :
							"Network Problem. Please try later",
						"danger"
					);
				}
			);
		}
	}
}
