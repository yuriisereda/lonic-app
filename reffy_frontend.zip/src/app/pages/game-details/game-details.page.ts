import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import {ActivatedRoute} from '@angular/router';
import { GameService } from '../../services/game/game.service';
import { GeneralService } from '../../services/general/general.service';
import {playForms, gameTypes, text, COACH, HIRED} from '../../../common/constants';
import * as moment from 'moment';
import {NavController, MenuController} from '@ionic/angular';

declare var google;

@Component({
  selector: 'app-game-details',
  templateUrl: './game-details.page.html',
  styleUrls: ['./game-details.page.scss'],
})
export class GameDetailsPage implements OnInit {
  isLoading: boolean = false;
  game_id: string = null;
  user_id: number = Number(localStorage.getItem('user_id'));
  gameData: any = null;
  text: any = text;
  isCoach: boolean = false;
  hasRating: boolean = false;
  hasReferee: boolean = false;
  isPlayed: boolean = false;

  @ViewChild('map',  {static: false}) mapElement: ElementRef;
  map: any;

  constructor(
    private actRoute: ActivatedRoute,
    private gameService: GameService,
    private generalService: GeneralService,
    private navCtrl: NavController,
    private menuCtrl: MenuController,
  ) {
    this.game_id = this.actRoute.snapshot.paramMap.get('game_id');
  }

  ngOnInit() {
    
  }

  ionViewWillEnter() {
    const type = localStorage.getItem('type');
    this.isCoach = (type === COACH);
    this.loadGame();
  }

  openMenu() {
    this.menuCtrl.enable(true, 'first');
    this.menuCtrl.open('first');
  }

  loadGame() {
    this.isLoading = true;
    this.gameService.fetchGame(Number(this.game_id)).subscribe(
      res => {
        this.isLoading = false;
        this.gameData = res;
        this.isPlayed = moment(this.gameData.start_time).isBefore(moment().utc());
        this.hasRating = (this.gameData && this.gameData.rating) ? true : false;
        this.hasReferee = this.getHiredReferee() ? true : false;
        if (this.hasReferee && !this.isPlayed) {
          this.gameData.status = "unavailable";
        }
        this.loadMap(this.gameData && this.gameData.ground_lat, this.gameData && this.gameData.ground_lng);
        console.log(res);
      },
      error => {
        this.isLoading = false;
        this.generalService.presentToast(
          error.message && error.message.length ?
            error.message
            : "Network Problem. Please try again after sometimes",
          "danger"
        );
      }
    )
  }

  loadMap(lat, lng) {
    let latLng = new google.maps.LatLng(lat, lng);
    let mapOptions = {
      center: latLng,
      zoom: 15,
      disableDefaultUI: true,
      mapTypeId: google.maps.MapTypeId.ROADMAP
    } 
    
    // LOAD THE MAP WITH THE PREVIOUS VALUES AS PARAMETERS.

    this.map = new google.maps.Map(this.mapElement.nativeElement, mapOptions);
    const options = {
      draggable: false,
      panControl: false,
      scrollwheel: false
    };
    this.map.setOptions(options);
  }

  formatDate(date) {
    return moment(date).format('YYYY-MM-DD HH:mm');
  }

  /**
   * @return hired referee on a game
   */
  getHiredReferee() {
    const item = this.gameData &&
      this.gameData.referees &&
      this.gameData.referees.find(item => item.status === HIRED);
    return item && item.user;
  }

  isRefereeOnGame() {
    const refereeOnGame = this.getHiredReferee();
    return (refereeOnGame && refereeOnGame.id) === this.user_id;
  }

  isAppliedOnGame() {
    const index = this.gameData &&
      this.gameData.referees &&
      this.gameData.referees.findIndex(item => (item.user && item.user.id) === this.user_id);

    return index !== -1;
  }

  getPlayForm(playFormId) {
    const item = playForms && playForms.find(item => item.id === playFormId);
    return item && item.title;
  }

  getGameType(gameTypeId) {
    const item = gameTypes && gameTypes.find(item => item.id === gameTypeId);
    return item && item.title;
  }

  goToUserDetailPage(user_id) {
    this.navCtrl.navigateRoot(`user-detail/${user_id}`, {animated: true});
  }

  goToRatePage() {
    const game_id = this.gameData && this.gameData.id;
    this.navCtrl.navigateRoot(`rate-game/${game_id}`, {animated: true});
  }

  goBack() {
    this.navCtrl.back({animated: true});
  }

  applyToGame() {
    const referee_id = this.user_id;
    const game_id = this.gameData && this.gameData.id;

    this.gameService.applyAsReferee(game_id, referee_id).subscribe(
      res => {
        this.generalService.presentToast(
          "Successfully Applied!",
          "primary"
        );
      },
      error => {
        this.generalService.presentToast(
          error.message && error.message.length ?
            error.message
            : "Network Problem. Please try again after sometimes",
          "danger"
        );
      }
    )
  }

  hireReferee(referee_id) {
    const game_id = Number(this.game_id);

    this.gameService.hireReferee(game_id, referee_id).subscribe(
      res => {
        this.navCtrl.navigateRoot(`confirmation`, {animated: true});
      },
      error => {
        this.generalService.presentToast(
          error.message && error.message.length ?
            error.message
            : "Network Problem. Please try again after sometimes",
          "danger"
        );
      }
    );
  }
}
