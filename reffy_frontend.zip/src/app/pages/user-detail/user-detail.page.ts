import { Component, OnInit } from '@angular/core';
import {MenuController, NavController} from '@ionic/angular';
import {ActivatedRoute} from '@angular/router';
import { UserService } from '../../services/user/user.service';
import { GeneralService } from '../../services/general/general.service';
import {COACH} from '../../../common/constants';
import {playForms} from '../../../common/constants';

@Component({
  selector: 'app-user-detail',
  templateUrl: './user-detail.page.html',
  styleUrls: ['./user-detail.page.scss'],
})
export class UserDetailPage implements OnInit {
  isLoading: boolean = false;
  user_id: string;
  userData: any = null;
  isUserCoach: boolean = false;
  refereePlayForms: string = null;

  constructor(
    private navCtrl: NavController,
    private actRoute: ActivatedRoute,
    private userService: UserService,
    private generalService: GeneralService,
    private menuCtrl: MenuController,
  ) {
    this.user_id = this.actRoute.snapshot.paramMap.get('user_id');
    this.fetchUser();
  }

  ngOnInit() {
  }

  openMenu() {
    this.menuCtrl.enable(true, 'first');
    this.menuCtrl.open('first');
  }

  fetchUser() {
    this.isLoading = true;
    const user_id = this.user_id;
    this.userService.fetchUser(user_id).subscribe(
      res => {
        this.isLoading = false;
        this.userData = res;
        this.isUserCoach = (this.userData.user_type === COACH);
        this.makeRefereePlayForms();
        console.log(this.userData);
      },
      error => {
        this.isLoading = false;
        this.generalService.presentToast(
          error.message && error.message.length ?
            error.message
            : "Network Problem. Please try again after sometimes",
          "danger"
        );
      }
    )
  }

  goBack() {
    this.navCtrl.back();
  }

  makeRefereePlayForms() {
    if (!this.isUserCoach) {
      const forms = this.userData && this.userData.referee_play_form && this.userData.referee_play_form.split(',');
      const strForms = forms && forms.map(form => {
        const data = playForms && playForms.find(item => item.id === form);
        return data && data.title;
      })

      this.refereePlayForms = strForms && strForms.join(' | ');
    }
  }
}
