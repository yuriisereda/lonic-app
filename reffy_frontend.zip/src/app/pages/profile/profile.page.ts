import {Component, OnInit, NgZone, ChangeDetectorRef, ElementRef} from '@angular/core';
import {ActivatedRoute} from '@angular/router';
import {NativeGeocoder, NativeGeocoderResult, NativeGeocoderOptions} from '@ionic-native/native-geocoder/ngx';
import {MenuController, NavController} from '@ionic/angular';
import {FileUploadService} from '../../services/file-upload/file-upload.service';
import {FormBuilder, FormGroup, Validators, FormControl} from '@angular/forms';
import {AuthenticationService} from '../../services/authentication/authentication.service';
import {GeneralService} from '../../services/general/general.service';
import {UserService} from '../../services/user/user.service';
import {COACH, playForms, REFEREE} from '../../../common/constants';

declare var google;

@Component({
	selector: 'app-profile',
	templateUrl: './profile.page.html',
	styleUrls: ['./profile.page.scss'],
})
export class ProfilePage implements OnInit {
	isSaving: boolean = false;
	signUpForm: FormGroup;
	user_id: number = Number(localStorage.getItem('user_id'));
	isSubmitted: boolean = false;
	userData: any = null;
	flag = localStorage.getItem('type') === REFEREE ? '1' : '0'; // 1 : referee, 0: coach
	autocomplete: { input: string; };
	autocompleteItems: any[];
	GoogleAutocomplete: any;
	city_name: any = null;
	lat: any;
	lng: any;
	playForms: any = playForms;
	checkedPlayForms: string[] = [];
	profilePicture = '';

	constructor(
		private formBuilder: FormBuilder,
		private actRoute: ActivatedRoute,
		private nativeGeocoder: NativeGeocoder,
		public zone: NgZone,
		private cdr: ChangeDetectorRef,
		private fileUploadService: FileUploadService,
		private authenticationService: AuthenticationService,
		private navController: NavController,
		private generalService: GeneralService,
		private userService: UserService,
		private el: ElementRef,
		private menuCtrl: MenuController,
	) {
		this.GoogleAutocomplete = new google.maps.places.AutocompleteService();
		this.autocomplete = {input: ''};
		this.autocompleteItems = [];
	}

	ngOnInit() {
	}

	ionViewWillEnter() {
		this.loadUser();
	}

	openMenu() {
		this.menuCtrl.enable(true, 'first');
		this.menuCtrl.open('first');
	}

	loadUser() {
		this.userService.fetchUser(this.user_id).subscribe(
			res => {
				this.userData = res;
				this.createForm();
			},
			error => {
				this.generalService.presentToast(
					error.message && error.message.length ?
						error.message
						: 'Network Problem. Please try again after sometimes',
					'danger'
				);
			}
		)
	}

	/**
	 * @description creates the form with validation
	 */
	private createForm(): void {
		const commonFormStructure = {
			email: [
				this.userData && this.userData.email,
				Validators.compose([
					Validators.required,
					Validators.pattern(
						'^[a-zA-Z0-9]{1}[a-zA-Z0-9._+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,3}$'
					)
				])
			],
			name: [
				this.userData && this.userData.username,
				Validators.required
			],
			mobile: [
				this.userData && this.userData.mobile_phone,
				Validators.required
			]
		};

		const coachFormStructure = {
			coach_club: [
				this.userData && this.userData.coach_club,
				Validators.required
			],
			coach_club_team: [
				this.userData && this.userData.coach_club_team,
				Validators.required
			]
		};

		const refereeFormStructure = {
			referee_id: [
				this.userData && this.userData.referee_id,
				Validators.required
			]
		};

		const formStructure = this.flag === '0' ? {
			...commonFormStructure,
			...coachFormStructure
		} : {
			...commonFormStructure,
			...refereeFormStructure
		};

		this.signUpForm = this.formBuilder.group(formStructure);
		this.profilePicture = this.userData && this.userData.photo_url;
		this.city_name = this.userData && this.userData.city_name;
		this.lat = this.userData && this.userData.city_lat;
		this.lng = this.userData && this.userData.city_lng;
		this.autocomplete.input = this.userData && this.userData.city_name;
		this.checkedPlayForms = this.userData && this.userData.referee_play_form && this.userData.referee_play_form.split(',');
	}

	// select profile picture
	async selectFile(event) {
		try {
			const response = await this.fileUploadService.showCameraGallery('image');
			console.log('CandidateProfilePage -> selectFile -> response', response);
			this.cdr.detectChanges();
			if (!response.error) {
				this.profilePicture = response.imageContent;
				this.cdr.detectChanges();
			}
		} catch (error) {
			console.log(error);
		}
	}

	// select city parts
	UpdateSearchResults() {
		if (this.autocomplete.input === '') {
			this.autocompleteItems = [];
			return;
		}
		this.GoogleAutocomplete.getPlacePredictions({input: this.autocomplete.input},
			(predictions, status) => {
				this.autocompleteItems = [];
				this.zone.run(() => {
					predictions && predictions.forEach((prediction) => {
						this.autocompleteItems.push(prediction);
					});
				});
			});
	}

	// when tap city on candidates list
	SelectSearchResult(item) {
		this.autocomplete.input = item && item.structured_formatting && item.structured_formatting.main_text;
		this.city_name = item && item.structured_formatting && item.structured_formatting.main_text;

		this.nativeGeocoder.forwardGeocode(item.description, {
			useLocale: true,
			maxResults: 5
		}).then((result: NativeGeocoderResult[]) => {
			this.zone.run(() => {
				this.lat = result[0].latitude;
				this.lng = result[0].longitude;
			});
		}).catch((error: any) => {
			console.log(error);
		});

		this.ClearCandidateList();
	}

	ClearCandidateList() {
		this.autocompleteItems = [];
	}

	ClearAutocomplete() {
		this.city_name = null;
		this.lat = null;
		this.lng = null;
		this.autocompleteItems = [];
	}

	scrollTo(el: Element) {
		if (el) {
			el.scrollIntoView({behavior: 'smooth'});
		}
	}

	/**
	 * @param playFormId: id of toggled playform
	 */
	onTogglePlayForm(playFormId) {
		const index = this.checkedPlayForms && this.checkedPlayForms.findIndex(item => item === playFormId);
		if (index === -1) {
			this.checkedPlayForms.push(playFormId);
		} else {
			this.checkedPlayForms.splice(index, 1);
		}
	}

	getChecked(id) {
		return (this.checkedPlayForms && this.checkedPlayForms.findIndex(item => item === id)) !== -1;
	}

	goBack() {
		this.navController.back({animated: true});
	}

	/**
	 * @description when click sign up button
	 */
	onSave() {
		if (!this.signUpForm.valid) {
			this.isSubmitted = true;
			Object.keys(this.signUpForm.controls).forEach(field => {
				const control = this.signUpForm.get(field);
				if (control instanceof FormControl) {
					control.markAsTouched({onlySelf: true});
				}
			});

			const invalidElements = this.el.nativeElement.querySelectorAll(
				'.ng-invalid'
			);

			if (invalidElements.length > 0) {
				this.scrollTo(invalidElements[0]);
			}
			return;
		}

		if (this.city_name === null) {
			return;
		}

		let data = {};

		if (this.flag === '0') { // when coach sign
			data = {
				id: this.userData && this.userData.id,
				username: this.signUpForm.value.name,
				photo_url: this.profilePicture.trim() !== '' ? this.profilePicture : null,
				mobile_phone: this.signUpForm.value.mobile,
				email: this.signUpForm.value.email,
				coach_club: this.signUpForm.value.coach_club,
				coach_club_team: this.signUpForm.value.coach_club_team,
				city_name: this.city_name,
				city_lat: 59.3293, // this.lat
				city_lng: 18.0686, // this.lng
				user_type: COACH,
			};
		} else { // when referee sign
			if (this.checkedPlayForms && this.checkedPlayForms.length === 0) {
				return;
			} else {
				data = {
					id: this.userData && this.userData.id,
					username: this.signUpForm.value.name,
					photo_url: this.profilePicture.trim() !== '' ? this.profilePicture : null,
					mobile_phone: this.signUpForm.value.mobile,
					email: this.signUpForm.value.email,
					referee_id: this.signUpForm.value.referee_id,
					referee_play_form: this.checkedPlayForms.toString(),
					city_name: this.city_name,
					city_lat: 59.3293, // this.lat
					city_lng: 18.0686, // this.lng
					user_type: REFEREE,
				};
			}
		}

		this.isSaving = true;
		this.userService.updateUser(data).subscribe(
			response => {
				this.isSaving = false;
				console.log('register response: ', response);
				localStorage.setItem('type', response.user_type);
				localStorage.setItem('matched_play_form', response.referee_play_form);
				localStorage.setItem('user_id', response.id);
				this.generalService.presentToast(
					'Profile updated successfully',
					'primary'
				);
			},
			error => {
				this.isSaving = false;
				this.generalService.presentToast(
					error.message && error.message.length ?
						error.message
						: 'Network Problem. Please try again after sometimes',
					'danger'
				);
			}
		);
	}
}
