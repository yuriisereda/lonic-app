import {ChangeDetectorRef, Component, ElementRef, NgZone, OnInit} from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { NativeGeocoder, NativeGeocoderResult } from '@ionic-native/native-geocoder/ngx';
import {MenuController, NavController} from '@ionic/angular';
import { UserService } from '../../services/user/user.service';
import { GameService } from '../../services/game/game.service';
import { GeneralService } from '../../services/general/general.service';
import { playForms, gameTypes } from '../../../common/constants';
import * as moment from 'moment';

declare var google;

@Component({
  selector: 'app-create-game',
  templateUrl: './create-game.page.html',
  styleUrls: ['./create-game.page.scss'],
})
export class CreateGamePage implements OnInit {
  isSaving: boolean = false;
  isLoading: boolean = false;
  userData: any = null;
  gameForm: FormGroup;
  isSubmitted: boolean = false;
  autocomplete: { input: string; };
  autocompleteItems: any[];
  GoogleAutocomplete: any;
  city_name : any = null;
  lat: any;
  lng: any;
  playForms: any = playForms;
  gameTypes: any = gameTypes;

  constructor(
    private formBuilder: FormBuilder,
    private el: ElementRef,
    private nativeGeocoder: NativeGeocoder,
    public zone: NgZone,
    private cdr: ChangeDetectorRef,
    private userService: UserService,
    private generalService: GeneralService,
    private gameService: GameService,
    private menuCtrl: MenuController,
    private navController: NavController
  ) {
    this.GoogleAutocomplete = new google.maps.places.AutocompleteService();
    this.autocomplete = { input: '' };
    this.autocompleteItems = [];
  }

  ngOnInit() {

  }

  ionViewWillEnter() {
    this.loadUser();
  }

  openMenu() {
    this.menuCtrl.enable(true, 'first');
    this.menuCtrl.open('first');
  }

  loadUser() {
    this.isLoading = true;
    const user_id = localStorage.getItem('user_id');
    this.userService.fetchUser(user_id).subscribe(
      res => {
        this.isLoading = false;
        this.userData = res;
        this.createForm();
        console.log('user: ', res);
      },
      error => {
        this.isLoading = false;
        this.generalService.presentToast(
          error.message && error.message.length
            ? error.message
            : "Network Problem. Please try again after sometimes",
          "danger"
        );
        console.log(error);
      }
    )
  }

  /**
   * @description creates the form with validation
   */
  private createForm(): void {
    this.autocomplete.input = this.userData.city_name;
    this.city_name = this.userData.city_name;
    this.lat = this.userData.city_lat;
    this.lng = this.userData.city_lng;

    const formStructure = {
      start_time: [
        moment().format('YYYY-MM-DD HH:mm'),
        Validators.required
      ],
      opponent: [
        "",
        Validators.required
      ],
      play_form: [
        this.playForms && this.playForms.length > 0 && this.playForms[0] && this.playForms[0].id,
        Validators.required
      ],
      play_time: [
        "",
        Validators.required
      ],
      game_type: [
        this.gameTypes && this.gameTypes.length > 0 && this.gameTypes[0] && this.gameTypes[0].id,
        Validators.required
      ],
      remuneration: [
        "",
        Validators.required
      ],
      information: [
        "",
        Validators.required
      ]
    };

    this.gameForm = this.formBuilder.group(formStructure);
  }

  // select city parts
  UpdateSearchResults() {
    if (this.autocomplete.input === '') {
      this.autocompleteItems = [];
      return;
    }
    this.GoogleAutocomplete.getPlacePredictions({ input: this.autocomplete.input },
      (predictions, status) => {
        this.autocompleteItems = [];
        this.zone.run(() => {
          predictions && predictions.forEach((prediction) => {
            this.autocompleteItems.push(prediction);
          });
        });
      });
  }

  // when tap city on candidates list
  SelectSearchResult(item) {
    this.autocomplete.input = item && item.structured_formatting && item.structured_formatting.main_text;
    this.city_name = item && item.structured_formatting && item.structured_formatting.main_text;

    this.nativeGeocoder.forwardGeocode(item.description, {
      useLocale: true,
      maxResults: 5
    }).then((result: NativeGeocoderResult[]) => {
      this.zone.run(() => {
        this.lat = result[0].latitude;
        this.lng = result[0].longitude;
      });
    }).catch((error: any) => {
      console.log(error);
    });

    this.ClearCandidateList();
  }

  ClearCandidateList() {
    this.autocompleteItems = [];
  }

  ClearAutocomplete() {
    this.city_name = null;
    this.lat = null;
    this.lng = null;
    this.autocompleteItems = [];
  }

  scrollTo(el: Element) {
    if (el) {
      el.scrollIntoView({ behavior: "smooth" });
    }
  }

  onCreate() {
    if (!this.gameForm.valid) {
      this.isSubmitted = true;
      Object.keys(this.gameForm.controls).forEach(field => {
        const control = this.gameForm.get(field);
        if (control instanceof FormControl) {
          control.markAsTouched({ onlySelf: true });
        }
      });

      const invalidElements = this.el.nativeElement.querySelectorAll(
        ".ng-invalid"
      );

      if (invalidElements.length > 0) {
        this.scrollTo(invalidElements[0]);
      }
      return;
    }

    const data = {
      ground_name: this.city_name,
      ground_lat: this.lat,
      ground_lng: this.lng,
      start_time: this.gameForm.value.start_time,
      opponent: this.gameForm.value.opponent,
      play_form: this.gameForm.value.play_form,
      play_time: this.gameForm.value.play_time,
      game_type: this.gameForm.value.game_type,
      remuneration: this.gameForm.value.remuneration,
      information: this.gameForm.value.information
    };

    console.log(data);
    // TODO call game_new endpoint
    this.isSaving = true;
    this.gameService.createGame(data).subscribe(
      res => {
        this.isSaving = false;
        console.log(res);
        this.generalService.presentToast(
          "Game creating success!",
          "primary"
        );
        this.navController.navigateRoot("/games");
      },
      error => {
        this.isSaving = false;
        this.generalService.presentToast(
          error.message && error.message.length
            ? error.message
            : "Network Problem. Please try again after sometimes",
          "danger"
        );
      }
    )
  }
}
