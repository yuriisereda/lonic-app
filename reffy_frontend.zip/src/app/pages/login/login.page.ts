import {Component, ElementRef, OnInit} from '@angular/core';
import { OneSignal } from '@ionic-native/onesignal/ngx';
import { Router } from "@angular/router";
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { AuthenticationService } from "../../services/authentication/authentication.service";
import { GeneralService } from "../../services/general/general.service";
import * as jwt_decode from "jwt-decode";

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {
  isLogging: boolean = false;
  loginForm: FormGroup;
  isSubmitted: boolean = false;

  constructor(
    private router: Router,
    private formBuilder: FormBuilder,
    private authenticationService: AuthenticationService,
    private generalService: GeneralService,
    private oneSignal: OneSignal,
    private el: ElementRef
  ) {
    
  }

  ngOnInit() {
    this.createForm();
  }

  /**
   * @description creates the form with validation
   */
  private createForm(): void {
    const formStructure = {
      username: [
        "",
        Validators.compose([
          Validators.required,
          Validators.pattern(
            "^[a-zA-Z0-9]{1}[a-zA-Z0-9._+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,3}$"
          )
        ])
      ],
      password: [
        "",
        Validators.required
      ],
    };

    this.loginForm = this.formBuilder.group(formStructure);
  }

  scrollTo(el: Element) {
    if (el) {
      el.scrollIntoView({ behavior: "smooth" });
    }
  }

  /**
   * when click login button
   */
  onLogin() {
    if (!this.loginForm.valid) {
      this.isSubmitted = true;
      Object.keys(this.loginForm.controls).forEach(field => {
        const control = this.loginForm.get(field);
        if (control instanceof FormControl) {
          control.markAsTouched({ onlySelf: true });
        }
      });

      const invalidElements = this.el.nativeElement.querySelectorAll(
        ".ng-invalid"
      );

      if (invalidElements.length > 0) {
        this.scrollTo(invalidElements[0]);
      }
      return;
    }

    const data = {
      username: this.loginForm.value.username,
      password: this.loginForm.value.password
    };

    this.isLogging = true;
    this.authenticationService.login(data).subscribe(
      response => {
        this.isLogging = false;
        const payload: any = jwt_decode(response.accessToken);
        localStorage.setItem('token', response.accessToken);
        localStorage.setItem('type', response.user_type);
        localStorage.setItem('matched_play_form', response.referee_play_form);
        localStorage.setItem('user_id', payload.id);
        this.oneSignal.setExternalUserId(payload.id);
        this.router.navigateByUrl("games");
      },
      error => {
        this.isLogging = false;
        this.generalService.presentToast(
          error.message && error.message.length
            ? error.message
            : "Network Problem. Please try again after sometimes",
          "danger"
        );
      }
    );
  }
}
