export const gameCardTestData = [
	{
		id: 1,
		coach: {
			id: 1,
			username: 'Anna'
		},
		ground_name: 'Stockholm',
		start_time: '2020-04-28 11:27:01',
		play_form: '1',
		referees: {
			id: 1,
			user: {
				id: 2,
				username: 'Stefan'
			},
			status: 'applied'
		}
	},
	{
		id: 2,
		coach: {
			id: 1,
			username: 'Anna'
		},
		ground_name: 'Stockholm',
		start_time: '2020-05-28 11:27:01',
		play_form: '3',
		referees: {
			id: 2,
			user: {
				id: 2,
				username: 'Stefan'
			},
			status: 'hired'
		}
	},
	{
		id: 1,
		coach: {
			id: 1,
			username: 'Anna'
		},
		ground_name: 'Stockholm',
		start_time: '2020-04-28 11:27:01',
		play_form: '1',
		referees: {
			id: 1,
			user: {
				id: 2,
				username: 'Stefan'
			},
			status: 'applied'
		}
	},
	{
		id: 1,
		coach: {
			id: 1,
			username: 'Anna'
		},
		ground_name: 'Stockholm',
		start_time: '2020-04-28 11:27:01',
		play_form: '1',
		referees: {
			id: 1,
			user: {
				id: 2,
				username: 'Stefan'
			},
			status: 'applied'
		}
	},
	{
		id: 1,
		coach: {
			id: 1,
			username: 'Anna'
		},
		ground_name: 'Stockholm',
		start_time: '2020-04-28 11:27:01',
		play_form: '1',
		referees: {
			id: 1,
			user: {
				id: 2,
				username: 'Stefan'
			},
			status: 'applied'
		}
	},
	{
		id: 1,
		coach: {
			id: 1,
			username: 'Anna'
		},
		ground_name: 'Stockholm',
		start_time: '2020-04-28 11:27:01',
		play_form: '1',
		referees: {
			id: 1,
			user: {
				id: 2,
				username: 'Stefan'
			},
			status: 'applied'
		}
	},
	{
		id: 1,
		coach: {
			id: 1,
			username: 'Anna'
		},
		ground_name: 'Stockholm',
		start_time: '2020-04-28 11:27:01',
		play_form: '1',
		referees: {
			id: 1,
			user: {
				id: 2,
				username: 'Stefan'
			},
			status: 'applied'
		}
	},
	{
		id: 1,
		coach: {
			id: 1,
			username: 'Anna'
		},
		ground_name: 'Stockholm',
		start_time: '2020-04-28 11:27:01',
		play_form: '1',
		referees: {
			id: 1,
			user: {
				id: 2,
				username: 'Stefan'
			},
			status: 'applied'
		}
	},
	{
		id: 1,
		coach: {
			id: 1,
			username: 'Anna'
		},
		ground_name: 'Stockholm',
		start_time: '2020-04-28 11:27:01',
		play_form: '1',
		referees: {
			id: 1,
			user: {
				id: 2,
				username: 'Stefan'
			},
			status: 'applied'
		}
	},
	{
		id: 1,
		coach: {
			id: 1,
			username: 'Anna'
		},
		ground_name: 'Stockholm',
		start_time: '2020-04-28 11:27:01',
		play_form: '1',
		referees: {
			id: 1,
			user: {
				id: 2,
				username: 'Stefan'
			},
			status: 'applied'
		}
	},
	{
		id: 1,
		coach: {
			id: 1,
			username: 'Anna'
		},
		ground_name: 'Stockholm',
		start_time: '2020-04-28 11:27:01',
		play_form: '1',
		referees: {
			id: 1,
			user: {
				id: 2,
				username: 'Stefan'
			},
			status: 'applied'
		}
	}
]