import { Injectable } from "@angular/core";
import {
  HttpEvent,
  HttpHandler,
  HttpInterceptor,
  HttpRequest
} from "@angular/common/http";
import { Observable } from "rxjs";

@Injectable()
export class InterceptorService implements HttpInterceptor {
  constructor() {}
  intercept(
    request: HttpRequest<any>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {
    // add authorization header with jwt token if available
    const accessToken = localStorage.getItem("token");
    if (accessToken && accessToken !== "undefined") {
      request = request.clone({
        setHeaders: {
          'x-access-token': accessToken
        }
      });
    }
    return next.handle(request);
  }
}
