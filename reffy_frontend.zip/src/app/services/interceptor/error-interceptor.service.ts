import { Injectable } from "@angular/core";
import {
  HttpEvent,
  HttpHandler,
  HttpRequest,
  HttpErrorResponse,
  HttpInterceptor
} from "@angular/common/http";
import { Observable, throwError } from "rxjs";
import { catchError, retry } from "rxjs/operators";
import { Router } from "@angular/router";
import { GeneralService } from "../general/general.service";
import { AuthenticationService } from "../authentication/authentication.service";

@Injectable()
export class ErrorInterceptorService implements HttpInterceptor {
  constructor(
    private router: Router,
    private generalService: GeneralService,
    private authenticationService: AuthenticationService,
  ) {}

  removeAndRedirectAfterLogout(): void {
    console.log(
      "ErrorInterceptorService -> removeAndRedirectAfterLogout -> removeAndRedirectAfterLogout"
    );
    localStorage.removeItem("token");
    this.router.navigateByUrl("/home");
  }

  logout() {
    this.removeAndRedirectAfterLogout();
  }

  intercept(
    request: HttpRequest<any>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {
    return next.handle(request).pipe(
      retry(1),
      catchError((error: HttpErrorResponse) => {
        console.log("TCL: ErrorInterceptorService -> error", error);
        let errorMessage = "";
        if (error.error.hasOwnProperty("errors") && error.error.errors.length) {
          error.error.errors.forEach(error => {
            this.generalService.presentToast(error, "danger");
          });
        } else if (Array.isArray(error.error.message)) {
          errorMessage += error.error.message[0];
          this.generalService.presentToast(errorMessage, "danger");
        } else {
          errorMessage += error.error.message;
          this.generalService.presentToast(errorMessage, "danger");
        }
        if (error.status === 401) {
          this.generalService.presentToast(
            "Token expired. Please login again",
            "danger"
          );
          this.logout();
        }
        return throwError(errorMessage);
      })
    );
  }
}
