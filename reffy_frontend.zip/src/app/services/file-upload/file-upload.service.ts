import {Injectable, ElementRef} from '@angular/core';
import {ActionSheetController, Platform} from '@ionic/angular';
import {Camera, CameraOptions} from '@ionic-native/camera/ngx';
import {config} from '../../../common/config';
import {appConfig} from '../../../common/app-config';
import {File, DirectoryEntry, FileEntry} from '@ionic-native/file/ngx';
import {HttpClient} from '@angular/common/http';
import {Base64} from '@ionic-native/base64/ngx';

declare var window;

@Injectable()
export class FileUploadService {
	constructor(
		private actionSheetController: ActionSheetController,
		private camera: Camera,
		private platform: Platform,
		private http: HttpClient,
		private base64: Base64,
		private file: File,
	) {
	}

	/**
	 * @description Show Camera and Gallery action sheet
	 */
	showCameraGallery(type: string): Promise<any> {
		return new Promise(async (resolve, reject) => {
			try {
				if (type === 'image') {
					const actionSheet = await this.actionSheetController.create({
						header: 'Complete Action Using:',
						buttons: [
							{
								text: 'Camera',
								icon: 'camera',
								handler: () =>
									resolve(
										this.openCameraOrGallery(
											this.camera.PictureSourceType.CAMERA,
											type
										)
									)
							},
							{
								text: 'Gallery',
								icon: 'images',
								handler: () =>
									resolve(
										this.openCameraOrGallery(
											this.camera.PictureSourceType.PHOTOLIBRARY,
											type
										)
									)
							},
							{
								text: 'Cancel',
								icon: 'close-circle',
								role: 'cancel',
								handler: () => reject({message: 'Photo Id dialog closed'})
							}
						]
					});
					await actionSheet.present();
				}
			} catch (error) {
				reject(error);
			}
		});
	}

	/**
	 *
	 * @param sourceType Source type can be Camera or Gallery
	 * @description Open camera or gallery depending on source type
	 */
	async openCameraOrGallery(sourceType: number, type: string): Promise<any> {
		let options: CameraOptions;
		if (type === 'image') {
			console.log('if :>> ');
			options = {
				quality: 90,
				sourceType,
				destinationType: this.platform.is('ios')
					? this.camera.DestinationType.FILE_URI
					: this.camera.DestinationType.NATIVE_URI,
				encodingType: this.camera.EncodingType.PNG,
				mediaType: this.camera.MediaType.PICTURE,
				correctOrientation: true,
				targetHeight: appConfig.uploadImageHeight,
				targetWidth: appConfig.uploadImageWidth
			};
		}

		try {
			const URI = await this.camera.getPicture(options);
			alert(URI);
			const imageContent = await this.getBase64StringByFilePath(URI);

			return {
				error: false,
				imageContent,
				type
			};
		} catch (error) {
			console.log('base64 conversion error');
			return {
				error: true,
				message: 'base64 conversion error'
			};
		}
	}

	/**
	 *
	 * @param URI Image URI returned after image is selected in Gallery/Camera
	 * @description Upload image to Cloudinary and return cloudinary URL
	 */
	getBase64StringByFilePath(fileURL): Promise<string> {
		return new Promise((resolve, reject) => {
			let fileName = fileURL.substring(fileURL.lastIndexOf('/') + 1);
			let filePath = fileURL.substring(0, fileURL.lastIndexOf('/') + 1);

			this.file.readAsDataURL(filePath, fileName).then(
				file64 => {
					console.log(file64);
					resolve(file64);
				}).catch(err => {
					reject(err);
				});
			});
	}
}
