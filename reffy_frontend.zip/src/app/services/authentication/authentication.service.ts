import { Injectable } from "@angular/core";
import { Observable, Observer } from "rxjs";
import { endPoints } from "../../../common/end-points";
import { HttpService } from "../http/http.service";
import { HttpClient } from "@angular/common/http";

@Injectable()
export class AuthenticationService extends HttpService {
  constructor(http: HttpClient) {
    super(http);
  }

  login(data): Observable<any> {
    return new Observable((observer: Observer<any>) => {
      this.post(endPoints.login, data).subscribe(
        response => {
          observer.next(response);
        },
        err => {
          observer.error(err.error);
        }
      );
    });
  }

  register(data): Observable<any> {
    return new Observable((observer: Observer<any>) => {
      this.post(endPoints.register, data).subscribe(
        response => {
          observer.next(response);
        },
        err => {
          observer.error(err.error);
        }
      );
    });
  }

  forgotPassword(data): Observable<any> {
    return new Observable((observer: Observer<any>) => {
      this.post(endPoints.forgotPassword, data).subscribe(
        response => {
          observer.next(response);
        },
        err => {
          observer.error(err.error);
        }
      );
    });
  }
}
