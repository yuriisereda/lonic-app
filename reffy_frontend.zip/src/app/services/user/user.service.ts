import { Injectable } from "@angular/core";
import { Observable, Observer } from "rxjs";
import { endPoints } from "../../../common/end-points";
import { HttpService } from "../http/http.service";
import { HttpClient } from "@angular/common/http";

@Injectable({
	providedIn: "root"
})
export class UserService extends HttpService {
	constructor(http: HttpClient) {
		super(http);
	}

	fetchUser(user_id): Observable<any> {
		return new Observable((observer: Observer<any>) => {
			this.get(`${endPoints.userLoad}?user_id=${user_id}`).subscribe(
				response => {
					observer.next(response);
				},
				err => {
					observer.error(err.error);
				}
			);
		});
	}

	updateUser(data): Observable<any> {
		return new Observable((observer: Observer<any>) => {
			this.post(endPoints.userUpdate, data).subscribe(
				response => {
					observer.next(response);
				},
				err => {
					observer.error(err.error);
				}
			);
		});
	}
}
