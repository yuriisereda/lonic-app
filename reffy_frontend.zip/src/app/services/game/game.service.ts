import { Injectable } from "@angular/core";
import { Observable, Observer } from "rxjs";
import { endPoints } from "../../../common/end-points";
import { HttpService } from "../http/http.service";
import { HttpClient } from "@angular/common/http";

@Injectable({
	providedIn: "root"
})
export class GameService extends HttpService {
	constructor(http: HttpClient) {
		super(http);
	}

	fetchGames(user_id): Observable<any> {
		return new Observable((observer: Observer<any>) => {
			this.post(endPoints.games, { user_id }).subscribe(
				response => {
					observer.next(response);
				},
				err => {
					observer.error(err.error);
				}
			);
		});
	}

	createGame(game): Observable<any> {
		return new Observable((observer: Observer<any>) => {
			this.post(endPoints.createGame, game).subscribe(
				response => {
					observer.next(response);
				},
				err => {
					observer.error(err.error);
				}
			);
		});
	}

	fetchGame(game_id): Observable<any> {
		return new Observable((observer: Observer<any>) => {
			this.get(`${endPoints.gameLoad}?game_id=${game_id}`).subscribe(
				response => {
					observer.next(response);
				},
				err => {
					observer.error(err.error);
				}
			);
		});
	}

	applyAsReferee(game_id, referee_id) {
		return new Observable((observer: Observer<any>) => {
			this.post(endPoints.applyAsReferee, {
				game_id,
				referee_id,
			}).subscribe(
				response => {
					observer.next(response);
				},
				err => {
					observer.error(err.error);
				}
			);
		});
	}

	hireReferee(game_id, referee_id) {
		return new Observable((observer: Observer<any>) => {
			this.post(endPoints.hireReferee, {
				game_id,
				referee_id,
			}).subscribe(
				response => {
					observer.next(response);
				},
				err => {
					observer.error(err.error);
				}
			);
		});
	}

	rateGame(game_id, referee_id, rate) {
		return new Observable((observer: Observer<any>) => {
			this.post(endPoints.rateGame, {
				game_id,
				referee_id,
				rate,
			}).subscribe(
				response => {
					observer.next(response);
				},
				err => {
					observer.error(err.error);
				}
			);
		});
	}
}
