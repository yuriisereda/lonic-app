import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { config } from '../../../common/config';

@Injectable()
export class HttpService {

  apiURL: string = config.hostAddress;

  constructor(
    private http: HttpClient
  ) {
  }

  get(endPoint: string): Observable<any> {
    return this.http.get(this.apiURL + endPoint);
  }

  post(endPoint: string, body: any): Observable<any> {
    return this.http.post(this.apiURL + endPoint, body);
  }

  put(endPoint: string, body: any): Observable<any> {
    return this.http.put(this.apiURL + endPoint, body);
  }

  delete(endPoint: string): Observable<any> {
    return this.http.delete(this.apiURL + endPoint);
  }
}
