import { Injectable } from '@angular/core';
import { ToastController, AlertController } from '@ionic/angular';

@Injectable({
  providedIn: 'root'
})
export class GeneralService {

  constructor(
    private toastController: ToastController,
    private alertController: AlertController
  ) { }


  async presentToast(message: string, color: string) {
    const toast = await this.toastController.create({
      message,
      position: 'top',
      cssClass: 'toast-panel',
      duration: 3000
    });
    await toast.present();
  }

  async presentAlert(message: string, buttons: any, header?: string) {
    const alert = await this.alertController.create({
      header,
      message,
      buttons
    });
    await alert.present();
  }
}
