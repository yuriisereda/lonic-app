export interface GameCardType {
	id: number
	coach: {
		id: number
		username: string
	}
	ground_name: string
	start_time: string
	play_form: string
	referees: {
		id: number
		user: {
			id: number
			username: string
		}
		status: string
	}
}