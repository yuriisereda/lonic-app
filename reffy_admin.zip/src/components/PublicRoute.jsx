import { Route, Redirect } from "react-router-dom";
import React from 'react';
const PublicRoute = ({component: Component, ...rest}) => {
  // console.log(0);
  return ( 
    <Route {...rest} render={props=>{
      if(localStorage.ma13AdminToken){
        // console.log(1);
        return <Redirect to={{pathname: rest.redirectRoute, extras: {...rest.location}}} />
      }else{
        // console.log(2);
        return <Component {...props}/> 
      }
    }} />
   );
}
 
export default PublicRoute;