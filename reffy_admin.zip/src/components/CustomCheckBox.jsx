import React, {Component} from "react";
import "../assets/css/CheckBox.css";

class CustomCheckBox extends Component {
	render() {
		return (
			<div className="check-area">
				<label className="play-check-wrapper">
					<input
						checked={this.props.checked}
						type="checkbox"
						onChange={() => this.props.onToggle(this.props.id)}
					/>
					<span className="play-check-mark"></span>
				</label>
				<span className="check-label">
					{this.props.title}
				</span>
			</div>
		);
	}
}

export default CustomCheckBox;
