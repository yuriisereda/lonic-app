export const ADMIN = "admin";
export const COACH = "coach";
export const REFEREE = "referee";
export const playForms = [
	{
		id: "1",
		title: "3 vs 3"
	},
	{
		id: "2",
		title: "5 vs 5"
	},
	{
		id: "3",
		title: "7 vs 7"
	},
	{
		id: "4",
		title: "9 vs 9"
	},
	{
		id: "5",
		title: "Futsal"
	},

	{
		id: "6",
		title: "11 vs 11"
	},
];