import React, { Component } from 'react';
import { Route, Switch,BrowserRouter, Redirect } from 'react-router-dom';
import './App.scss';
import './assets/css/material-dashboard.css';
import './assets/css/demo.css';

// Containers
import DefaultLayout from './containers/DefaultLayout/DefaultLayout';

import Login from "./views/Pages/Login/Login";
import ForgotPassword from './views/Pages/ForgotPassword/ForgotPassword';
import {ToastsContainer, ToastsStore, ToastsContainerPosition} from 'react-toasts';
import PublicRoute from './components/PublicRoute';

class App extends Component {

  render() {
    // console.log = () => {};
    return (
      <BrowserRouter>
          <ToastsContainer store={ToastsStore} position={ToastsContainerPosition.TOP_RIGHT}/>
          <div className="App">
            <div className="">
              <Switch>
                <PublicRoute exact path="/login" component={Login} redirectRoute={'/dashboard/users'}/>
                <PublicRoute exact path="/forgot-password" component={ForgotPassword} redirectRoute={'/dashboard/users'}/>
                <Route path="/dashboard" component={DefaultLayout} />
                <Route path="/" component={DefaultLayout} />
                <Route path="*" render={() => <Redirect to="/" />}/>
              </Switch>
            </div>
          </div>
        </BrowserRouter>
    );
  }
}

export default App;
