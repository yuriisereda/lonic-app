import React, { Component } from "react";
import { Redirect, Route, Switch } from "react-router-dom";
import { Link } from "react-router-dom";
import jwt_decode from "jwt-decode";
import ProtectedRoute from "../../components/ProtectedRoute";

import Users from "../../views/Pages/Users/Users";
import ViewUser from "../../views/Pages/Users/ViewUser";
import EditUser from "../../views/Pages/Users/EditUser";
import Banner from "../../views/Pages/Banner/Banner";

class DefaultLayout extends Component {
  state={
    isMenuOpen: true,
    adminData: null
  }
  /**
   * signOut - to logout from the admin panel and clear the session data
   */
  signOut(){
    localStorage.clear();
    this.props.history.push("/login");
  }

  /**
   * getMenuClass - To get the menu class accoording to the route path and set the active menu
   * @param {string} path name of the path
   */
  getMenuClass(path){
    return this.props.location.pathname === path ? 'nav-item active' : 'nav-item';
  }

  /**
   * _toggleMenu - To handle the opening and closing the side menu
   */
  _toggleMenu = ()=>{
    const { isMenuOpen } = this.state;
    if(isMenuOpen){
      document.body.classList.add('sidebar-mini');
    } else{
      document.body.classList.remove('sidebar-mini');
    }
    this.setState({ isMenuOpen: !isMenuOpen });
  }

  /**
   * _toggleMobileMenu - To handle the opening and closing the side menu on mobile version
   */
  _toggleMobileMenu = ()=>{
    const { isMenuOpen } = this.state;
    if(isMenuOpen){
      document.getElementsByTagName('html')[0].classList.add('nav-open');
    } else{
      document.getElementsByTagName('html')[0].classList.remove('nav-open');
    }
    this.setState({ isMenuOpen: !isMenuOpen });
  }

  componentDidMount(){
    // set the admin data from auth token
    if(localStorage.ma13AdminToken){
      console.log('token :', jwt_decode(localStorage.ma13AdminToken));
      this.setState({ adminData: jwt_decode(localStorage.ma13AdminToken) });
    } 
  }

  render() {
    const { isMenuOpen, adminData } = (this.state);
    
    return (
      <div className="app">
        <div className="wrapper">
          <div
            className="sidebar"
            data-color="rose"
            data-background-color="black"
            data-image="../../assets/img/sidebar-1.jpg"
          >
            <div className="logo">
              <a
                href="http://www.creative-tim.com"
                className="simple-text logo-mini"
              >
                
              </a>
              <a
                href="http://www.creative-tim.com"
                className="simple-text logo-normal"
              >
              Admin Panel
              </a>
            </div>
            <div className="sidebar-wrapper">
              <div className="user">
                <div className="photo">
                  <img src="../../assets/img/user.png" alt="avatar" />
                </div>
                <div className="user-info">
                  <a
                    data-toggle="collapse"
                    href="#collapseExample"
                    className="username"
                  >
                    {adminData && <span>
                      {adminData.firstName} {adminData.lastName}
                    </span>}
                  </a>                  
                </div>
              </div>
              <ul className="nav">                
                <li className={this.getMenuClass('/dashboard/users')}>
                  <Link to="/dashboard/users" className="nav-link">                    
                    <i className="material-icons">people</i>
                    <p>Users</p>
                  </Link>
                </li>
                <li className={this.getMenuClass('/dashboard/banner')}>
                  <Link to="/dashboard/banner" className="nav-link">
                    <i className="material-icons">flag</i>
                    <p>Banner</p>
                  </Link>
                </li>
              </ul>
            </div>
          </div>
          <div className="main-panel">
            <nav className="navbar navbar-expand-lg navbar-transparent navbar-absolute fixed-top ">
              <div className="container-fluid">
                <div className="navbar-wrapper">
                  <div className="navbar-minimize">
                    <button
                      id="minimizeSidebar"
                      className="btn btn-just-icon btn-white btn-fab btn-round"
                      onClick={()=>this._toggleMenu()}
                    >
                      <i className="material-icons text_align-center visible-on-sidebar-regular">
                        more_vert
                      </i>
                      <i className="material-icons design_bullet-list-67 visible-on-sidebar-mini">
                        view_list
                      </i>
                    </button>
                  </div>
                  <span className="navbar-brand">
                    {/* Dashboard */}
                  </span>
                </div>
                <button
                  className={isMenuOpen ? 'navbar-toggler' : 'navbar-toggler toggled'}
                  type="button"
                  data-toggle="collapse"
                  aria-controls="navigation-index"
                  aria-expanded="false"
                  aria-label="Toggle navigation"
                  onClick={()=>this._toggleMobileMenu()}
                >
                  <span className="sr-only">Toggle navigation</span>
                  <span className="navbar-toggler-icon icon-bar"></span>
                  <span className="navbar-toggler-icon icon-bar"></span>
                  <span className="navbar-toggler-icon icon-bar"></span>
                </button>
                <div className="collapse navbar-collapse justify-content-end">                 
                  <ul className="navbar-nav">                    
                    <li className="nav-item dropdown" onClick={()=>this.signOut()}>
                    <i className="material-icons" style={{cursor: 'pointer'}}>
                      logout
                    </i>
                      <div
                        className="dropdown-menu dropdown-menu-right"
                        aria-labelledby="navbarDropdownProfile"
                      >
                        <a className="dropdown-item" href=" ">
                          Profile
                        </a>
                        <a className="dropdown-item" href=" ">
                          Settings
                        </a>
                        <div className="dropdown-divider"></div>
                        <a className="dropdown-item" href=" ">
                          Log out
                        </a>
                      </div>
                    </li>
                  </ul>
                </div>
              </div>
            </nav>

            <div className="content">
              <Switch>
                <ProtectedRoute
                  path={`/user/:id`}
                  component={ViewUser}
                  redirectRoute={"/login"}
                />
                <ProtectedRoute
                  path={`/edit-user/:id`}
                  component={EditUser}
                  redirectRoute={"/login"}
                />
                <ProtectedRoute
                  path={`${this.props.match.path}/users`}
                  component={Users}
                  redirectRoute={"/login"}
                />
                <ProtectedRoute
                  path={`${this.props.match.path}/banner`}
                  component={Banner}
                  redirectRoute={"/login"}
                />
                <Route path="/" render={() => <Redirect to="/dashboard/users" />} />
              </Switch>
            </div>
            <footer className="footer">
              <div className="container-fluid">                
                <div className="copyright float-right">
                  &copy;
                  MA13
                </div>
              </div>
            </footer>
            {!isMenuOpen && <div className="close-layer visible" onClick={()=>this._toggleMobileMenu()}></div>}
          </div>
        </div>        
        
      </div>
    );
  }
}

export default DefaultLayout;
