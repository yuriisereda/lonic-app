import React, {Component} from "react";
import {getAllUsers} from "../../../http/http-calls";
import CustomTable from "../../../components/CustomTable";
import {ToastsStore} from "react-toasts";
import {ADMIN} from "../../../config/constants";

class Users extends Component {
	state = {
		userList: [],
		headerKeys: [
			{id: "id", label: "id"},
			{id: "name", label: "Name"},
			{id: "email", label: "Email"},
			{id: "mobile", label: "Mobile No."},
			{id: "userType", label: "User Type"},
			{id: "city", label: "City"},
			// {id: 'status', label: 'Status'},
			{id: "action", label: "Action"}
		],
		loadingData: false,
	};

	/**
	 * To manage the loading for various actions
	 * @param key show loading for which action
	 * @param value boolean value to show or hide loading
	 * @memberof Renters
	 */
	_manageLoading = (key, value) => {
		let {loadingData} = this.state;
		if (key === "data") {
			loadingData = value;
		}
		this.setState({loadingData});
	};

	/**
	 * _getAllUsers - To get the list of all users
	 */
	_getAllUsers() {
		this._manageLoading("data", true);
		getAllUsers().then(
			response => {
				console.log('users', response);
				this._manageLoading("data", false);
				let userList =
					response &&
					response.users &&
					response.users.filter(each => each.user_type !== ADMIN).map(each => {
						return {
							id: each.id,
							name: each.username,
							email: each.email,
							mobile: each.mobile_phone || 'N/A',
							userType: each.user_type,
							city: each.city_name || 'N/A',
							status: each.isActive ? 'Active' : 'Inactive',
							action: ""
						};
					});
				this.setState({userList, userListBackup: userList});
			},
			error => {
				console.log('error');
				console.log(error);
				this._manageLoading("data", false);
				ToastsStore.error(error.message);
			}
		);
	}

	componentDidMount() {
		this._getAllUsers();
	}

	/**
	 * To render the customised column views
	 */
	_dataFormat = (cell, row, header) => {
		if (header === "action") {
			return (
				<React.Fragment>
					<div className="td-actions">
						<button type="button" rel="tooltip" className="btn btn-warning btn-round" title="View"
										onClick={() => this._viewUserDetails(row.id)}>
							<i className="material-icons">visibility</i>
						</button>
						&nbsp;   &nbsp;
						<button type="button" rel="tooltip" className="btn btn-info btn-round" title="Edit"
										onClick={() => this._goToEditUser(row.id)}>
							<i className="material-icons">edit</i>
						</button>
					</div>
				</React.Fragment>
			);
		} else {
			return cell;
		}
	};

	/**
	 * To navigate to view user page
	 */
	_viewUserDetails = (id) => {
		this.props.history.push("/user/" + id);
	}

	/**
	 * To navigate to edit user page
	 */
	_goToEditUser = (id) => {
		this.props.history.push("/edit-user/" + id);
	}

	render() {
		const {loadingData} = this.state;
		return (
			<div className="animated fadeIn">
				<div className="row">
					<div className="col-md-12">
						<div className="card">
							<div className="card-header card-header-icon card-header-rose">
								<div className="card-icon">
									<i className="material-icons">people</i>
								</div>
								<h4 className="card-title ">User List</h4>
							</div>
							{!loadingData ? <div className="card-body">
									<CustomTable
										tableData={this.state.userList}
										headerKeys={this.state.headerKeys}
										dataFormat={this._dataFormat}>
									</CustomTable>
								</div> :
								<div className="card-body">
									<div className="loading-data">
										<i className="fa fa-spinner fa-spin loader-spinner"/>
										Loading User List..
									</div>
								</div>}
						</div>
					</div>
				</div>
			</div>
		);
	}
}

export default Users;
