import React, {Component} from 'react';
import {getUserDetails, updateUser} from '../../../http/http-calls';
import {ToastsStore} from 'react-toasts';
import {COACH, REFEREE} from "../../../config/constants";
import CustomCheckBox from "../../../components/CustomCheckBox";
import {playForms} from "../../../config/constants";

class EditUser extends Component {
	state = {
		userDetails: null,
		loadingUserDetails: false,
		savingData: false,
		errors: {},
		isDirty: {
			username: false,
			mobile_phone: false,
			birthYear: false,
			email: false
		},
		loading: false,
		checkedPlayForms: null
	}

	componentDidMount() {
		this._getUserDetails(this.props.match.params.id);
	}

	/**
	 * _handleOnChange
	 * To handle input on change and set the values to state
	 */
	_handleOnChange = ({currentTarget}, key) => {
		console.log('key, :', key, currentTarget.value);
		const {userDetails} = this.state;
		userDetails[key] = currentTarget.value;
		this.setState({userDetails});
		this._validateForm();
	}

	/**
	 * To handle submit of the form and validate it
	 */
	_handleOnSubmit = event => {
		event.preventDefault();
		const {isDirty} = this.state;
		isDirty.email = true;
		isDirty.username = true;
		isDirty.mobile_phone = true;
		isDirty.birthYear = true;
		this.setState({isDirty});
		console.log(this.state.isDirty);
		let errors = this._validateForm();
		console.log(errors);
		// this.setState({errors});
		if (!errors) {
			console.log("Make API call");
			this._updateUser();
		}
	};

	/**
	 * To Validate the form and show the error messages
	 */
	_validateForm() {
		const {userDetails, errors, isDirty} = this.state;
		Object.keys(userDetails).forEach(each => {
			if (each === "email" && isDirty.email) {
				if (!userDetails.email.trim().length) {
					errors.email = "Email is Required";
				} else if (
					userDetails.email.trim().length &&
					!new RegExp(
						"^[a-zA-Z0-9]{1}[a-zA-Z0-9._+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,3}$"
					).test(userDetails.email)
				) {
					errors.email = "Please enter valid Email";
				} else {
					delete errors[each];
					isDirty.email = false;
				}
			} else if (each === "username" && isDirty.username) {
				if (!userDetails.username) {
					errors[each] = "First name is Required";
				} else {
					delete errors[each];
					isDirty.username = false;
				}
			}
			// else if (each === "mobile_phone" && isDirty.mobile_phone) {
			//   if (userDetails.mobile_phone && isNaN(userDetails.mobile_phone)) {
			//     errors[each] = "mobile_phone must a number";
			//   } else {
			//     delete errors[each];
			//     isDirty.mobile_phone = false;
			//   }
			// }
		});
		this.setState({errors});
		return Object.keys(errors).length ? errors : null;
	}

	/**
	 * _backtoUsers- To go back to the user list page
	 */
	_backtoUsers = () => {
		this.props.history.push("/dashboard/users");
	}

	/**
	 * _getUserDetails - To get the user details by User ID
	 */
	_getUserDetails = (id) => {
		this.setState({loadingUserDetails: true});
		getUserDetails({user_id: id})
			.then((response) => {
				let userDetails = response;
				console.log(userDetails);
				const playForms = userDetails.referee_play_form && userDetails.referee_play_form.split(',');
				this.setState({checkedPlayForms: playForms});
				this.setState({userDetails, loadingUserDetails: false});
			}, (error) => {
				this.setState({loadingUserDetails: false});
				console.log('error :', error);
			})
	}

	/**
	 * _updateUser - To prepare the updated data and make the api call to save
	 */
	_updateUser = () => {
		this.setState({savingData: true});
		const {
			userDetails,
		} = this.state;

		const commonData = {
			id: userDetails.id,
			username: userDetails.username,
			email: userDetails.email,
			mobile_phone: userDetails.mobile_phone,
			photo_url: userDetails.photo_url,
			user_type: userDetails.user_type
		};
		let ownData = {};
		if (userDetails.user_type === COACH) {
			ownData['coach_club'] = userDetails.coach_club;
			ownData['coach_club_team'] = userDetails.coach_club_team;
		} else if (userDetails.user_type === REFEREE) {
			ownData['referee_id'] = userDetails.referee_id;
			ownData['referee_play_form'] = this.state.checkedPlayForms.toString();
		}
		const data = {
			...commonData,
			...ownData
		};
		// update user
		updateUser(data)
			.then((response) => {
				console.log('response :', response);
				this.setState({savingData: false});
				ToastsStore.success('User details updated successfully');
				this.props.history.push("/user/" + this.state.userDetails.id);
			}, (error) => {
				console.log('error :', error);
				this.setState({savingData: false});
				ToastsStore.error('Something went wrong!', 1500);
			});
	}

	/**
	 * @description when play form toggled
	 */
	onToggle = (id) => {
		let data = JSON.parse(JSON.stringify(this.state.checkedPlayForms));
		const index = data.findIndex(each => each === id);
		if (index === -1) {
			data.push(id);
		} else {
			data.splice(index, 1);
		}

		this.setState({checkedPlayForms: data});
	}

	render() {
		const {
			userDetails,
			loadingUserDetails,
			savingData,
			errors,
			loading,
			checkedPlayForms,
		} = this.state;

		return (
			<div>
				<div className="row">
					<div className="col-md-12">
						<div className="card">
							<div className="card-header card-header-icon card-header-rose">
								<div className="card-icon">
									<i className="material-icons">perm_identity</i>
								</div>
								<h4 className="card-title">Edit User Details
								</h4>
							</div>
							{!loadingUserDetails && !loading ? <div className="card-body">
									{userDetails && <form noValidate>
										<div className="row">
											<div className="col-md-4">
												<div className="form-group">
													<label className="bmd-label-floating">Name</label>
													<input
														type="text"
														className="form-control"
														value={userDetails.username || ''}
														onChange={(e) => this._handleOnChange(e, 'username')}
													/>
													{errors && (
														<div className="login-validation-error">
															{errors.username}
														</div>
													)}
												</div>
											</div>
											<div className="col-md-4">
												<div className="form-group">
													<label className="bmd-label-floating">Email address</label>
													<input type="email" className="form-control" value={userDetails.email || ''}
																 onChange={(e) => this._handleOnChange(e, 'email')}/>
													{errors && (
														<div className="login-validation-error">
															{errors.email}
														</div>
													)}
												</div>
											</div>
											<div className="col-md-4">
												<div className="form-group">
													<label className="bmd-label-floating">mobile_phone Number</label>
													<input
														type="text"
														className="form-control"
														value={userDetails.mobile_phone || ''}
														onChange={(e) => this._handleOnChange(e, 'mobile_phone')}/>
													{errors && (
														<div className="login-validation-error">
															{errors.mobile_phone}
														</div>
													)}
												</div>
											</div>
										</div>
										<div className="row">
											<div className="col-md-4">
												<div className="form-group">
													<label className="bmd-label-floating">City</label>
													<input
														type="text"
														className="form-control"
														value={userDetails.city_name || ''}
														disabled={true}
														onChange={(e) => this._handleOnChange(e, 'city_name')}/>
												</div>
											</div>
											{
												userDetails.user_type === COACH ?
													<div className="col-md-4">
														<div className="form-group">
															<label className="bmd-label-floating">Club</label>
															<input
																type="text"
																className="form-control"
																value={userDetails.coach_club || ''}
																onChange={(e) => this._handleOnChange(e, 'coach_club')}/>
														</div>
													</div> :
													<div className="col-md-4">
														<div className="form-group">
															<label className="bmd-label-floating">Referee ID</label>
															<input
																type="text"
																className="form-control"
																value={userDetails.referee_id || ''}
																onChange={(e) => this._handleOnChange(e, 'referee_id')}/>
														</div>
													</div>
											}
											{
												userDetails.user_type === COACH ?
													<div className="col-md-4">
														<div className="form-group">
															<label className="bmd-label-floating">Team</label>
															<input
																type="text"
																className="form-control"
																value={userDetails.coach_club_team || ''}
																onChange={(e) => this._handleOnChange(e, 'coach_club_team')}/>
														</div>
													</div> :
													<div className="col-md-4">
														<div className="form-group">
															<label className="bmd-label-floating">Play Form</label>
															<div className="row">
																{
																	playForms && playForms.map((item, key) => (
																		<div key={key} className="col-md-6">
																			<CustomCheckBox
																				key={key + 'check'}
																				id={item.id}
																				title={item.title}
																				checked={checkedPlayForms.findIndex(form => form === item.id) !== -1}
																				onToggle={this.onToggle}
																			/>
																		</div>
																	))
																}
															</div>
														</div>
													</div>
											}
										</div>
										<div className="row">
											<div className="col-md-12">
												<button
													type="submit"
													className="btn btn-rose pull-right"
													disabled={savingData}
													onClick={(e) => this._handleOnSubmit(e)}
												>
													{savingData ? (
														<>
															<i className="fa fa-spinner fa-spin mr5"/>
															&nbsp;&nbsp;
														</>
													) : null}
													Save
												</button>
												<button
													type="button"
													className="btn btn-default pull-right mr-2"
													onClick={() => this._backtoUsers()}>Back to List
												</button>
											</div>
										</div>
									</form>}
								</div> :
								<div className="card-body">
									<div className="loading-data">
										<i className="fa fa-spinner fa-spin loader-spinner"/>
										Loading User Details..
									</div>
								</div>}
						</div>
					</div>
				</div>
			</div>);
	}
}

export default EditUser;