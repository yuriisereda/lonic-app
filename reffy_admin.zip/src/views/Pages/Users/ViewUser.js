import React, { Component } from 'react';
import { getUserDetails } from '../../../http/http-calls';
import { ToastsStore } from 'react-toasts';
import {COACH, playForms} from "../../../config/constants";

class ViewUser extends Component {
  state = { 
    userDetails: null,
    loadingUserDetails: false
  }

  componentDidMount() {
    this._getUserDetails(this.props.match.params.id);
  }

  /**
   * _backtoUsers - To go back to the user list page
   */
  _backtoUsers = ()=>{
    this.props.history.push("/dashboard/users");
  }

  /**
   * _gotoEditUsers - To navigate to edit user page
   */
  _gotoEditUsers=()=>{
    this.props.history.push("/edit-user/" + this.state.userDetails.id);
  }

  /**
   * _getUserDetails - To get the user details by User ID
   */
  _getUserDetails=(id)=>{
    this.setState({ loadingUserDetails: true });
    getUserDetails({user_id: id})
    .then((response)=>{
      console.log('response :', response);
      let userDetails = response;
      this.setState({ userDetails, loadingUserDetails: false });
    },(error)=>{
      console.log('error :', error);
      this.setState({ loadingUserDetails: false });
      ToastsStore.error(error.message, 1500);
    })
  }

  render() { 
    const { userDetails, loadingUserDetails } = this.state;

    return ( <div>
      <div className="row">
            <div className="col-md-12">
              <div className="card card-profile text-left">
                <div className="card-header card-header-icon card-header-rose">
                  <div className="card-icon">
                    <i className="material-icons">perm_identity</i>
                  </div>
                  <h4 className="card-title">View User Details
                  </h4>
                </div>
                { !loadingUserDetails && userDetails &&  <div className="card-avatar" style={{margin: '10px auto 0'}}>
                  <a href=" ">
                    <img className="img" src={userDetails.photo_url || '../../../assets/img/user.png'} alt="user-img"/>
                  </a>
                </div>}
                {!loadingUserDetails ? <div className="card-body">
                  {userDetails && <form>                   
                    <div className="row">
                      <div className="col-md-4">
                        <div className="form-group">
                          <label className="bmd-label-floating">Name</label>
                          <div> {userDetails.username || 'N/A'}</div>
                        </div>
                      </div>
                      <div className="col-md-4">
                        <div className="form-group">
                          <label className="bmd-label-floating">Email address</label>
                          <div> {userDetails.email || 'N/A'}</div>
                        </div>
                      </div>
                      <div className="col-md-4">
                        <div className="form-group">
                          <label className="bmd-label-floating">Mobile Number</label>
                          <div> {userDetails.mobile_phone || 'N/A'}</div>
                        </div>
                      </div>
                    </div>
                    <div className="row">                      
                      <div className="col-md-4">
                        <div className="form-group">
                          <label className="bmd-label-floating">User Type</label>
                          <div> {userDetails.user_type || 'N/A'}</div>
                        </div>
                      </div>
                      <div className="col-md-4">
                        <div className="form-group">
                          <label className="bmd-label-floating">City</label>
                          <div> {userDetails.city_name || 'N/A'}</div>
                        </div>
                      </div>
                      {
                        userDetails.user_type === COACH ?
                          <div className="col-md-4">
                            <div className="form-group">
                              <label className="bmd-label-floating">Club</label>
                              <div> {userDetails.coach_club || 'N/A'}</div>
                            </div>
                          </div> :
                          <div className="col-md-4">
                            <div className="form-group">
                              <label className="bmd-label-floating">Referee ID</label>
                              <div> {userDetails.referee_id || 'N/A'}</div>
                            </div>
                          </div>
                      }
                    </div>
                    <div className="row">
                      <div className="col-md-4">

                      </div>
                      {
                        userDetails.user_type === COACH ?
                          <div className="col-md-4">
                            <div className="form-group">
                              <label className="bmd-label-floating">Team</label>
                              <div> {userDetails.coach_club_team || 'N/A'}</div>
                            </div>
                          </div> :
                          <div className="col-md-8">
                            <div className="form-group">
                              <label className="bmd-label-floating">Play Form</label>
                              <div>
                                {(userDetails.referee_play_form &&
                                  userDetails.referee_play_form.split(',') &&
                                  userDetails.referee_play_form.split(',').map(
                                  (item, key) => {
                                    const data = playForms.find(form => form.id === item);
                                    if (key === (userDetails.referee_play_form.split(',').length - 1)) {
                                      return data && data.title
                                    }
                                    return data && data.title + ', '
                                  }
                                )) || 'N/A'}
                              </div>
                            </div>
                          </div>
                      }
                    </div>
                    <div className="row">
                      <div className="col-md-12">                        
                        <button type="button" className="btn btn-info pull-right" onClick={()=>this._gotoEditUsers()}>Edit</button>
                        <button type="button" className="btn btn-default pull-right mr-2" onClick={()=>this._backtoUsers()}>Back to List</button>
                      </div>           
                    </div>
                  </form>}
                </div>:
                <div className="card-body">
                    <div className="loading-data">
                    <i className="fa fa-spinner fa-spin loader-spinner" />
                    Loading User Details..</div>
                  </div>}
              </div>
            </div>            
          </div>
    </div> );
  }
}
 
export default ViewUser;