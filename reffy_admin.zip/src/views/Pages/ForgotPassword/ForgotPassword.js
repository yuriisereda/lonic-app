import React, { Component } from "react";
import { fotgotPassword } from "../../../http/http-calls";
import { ToastsStore } from "react-toasts";
class ForgotPassword extends Component {
  state = {
    admin: {
      email: ""
    },
    errors: {},
    isDirty: {
      email: false
    },
    loading: false
  };
  /**
   * To go back to login
   */
  _backToLogin = () => {
    this.props.history.push("login");
  };

  /**
   * To handle in input change and set the value to state
   */
  _handleOnChange = ({ currentTarget }) => {
    const { admin, isDirty } = this.state;
    admin[currentTarget.name] = currentTarget.value;
    isDirty[currentTarget.name] = true;
    this.setState({ admin });
    this._validateForm();
  };

  /**
   * To handle the form submit and validate it
   */
  _handleOnSubmit = event => {
    event.preventDefault();
    const { isDirty } = this.state;
    isDirty.email = true;
    this.setState({ isDirty });
    console.log(this.state.isDirty);
    let errors = this._validateForm();
    console.log(errors);
    if (!errors) {
      console.log("Make API call");
      this._fotgotPassword();
    }
  };

  /**
   * To validate the form
   */
  _validateForm() {
    const { admin, errors, isDirty } = this.state;
    // console.log(admin, isDirty);
    Object.keys(admin).forEach(each => {
      if (each === "email" && isDirty.email) {
        if (!admin.email.trim().length) {
          errors.email = "Email is Required";
        } else if (
          admin.email.trim().length &&
          !new RegExp(
            "^[a-zA-Z0-9]{1}[a-zA-Z0-9._+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,3}$"
          ).test(admin.email)
        ) {
          errors.email = "Please enter valid Email";
        } else {
          delete errors[each];
          isDirty.email = false;
        }
      }
    });
    this.setState({ errors });
    return Object.keys(errors).length ? errors : null;
  }

  /**
   * To manage the loading
   */
  _manageLoading = value => {
    let { loading } = this.state;
    loading = value;
    this.setState({ loading });
  };

  /**
   * Make forgot password api call
   */
  _fotgotPassword = () => {
    this._manageLoading(true);
    fotgotPassword(this.state.admin).then(
      response => {
        console.log(response);
        ToastsStore.success(response.message, 3000);
        this._manageLoading(false);
        this.props.history.push("login");
      },
      error => {
        console.log(error);
        ToastsStore.error(error.reason, 3000);
        this._manageLoading(false);
      }
    );
  };


  render() {
    const { admin, errors, loading } = this.state;
    return (
      <div>
        <nav className="navbar navbar-expand-lg navbar-transparent navbar-absolute fixed-top text-white">
          <div className="container">
            <div className="navbar-wrapper">
              <a className="navbar-brand" href="#pablo">
                MA13 Logo
              </a>
            </div>
          </div>
        </nav>
        <div className="wrapper wrapper-full-page">
          <div
            className="page-header login-page header-filter login-bg"
            filter-color="black"
          >
            <div className="container">
              <div className="row">
                <div className="col-lg-5 col-md-6 col-sm-8 ml-auto mr-auto">
                  <form className="form" onSubmit={this._handleOnSubmit} noValidate>
                    <div className="card card-login">
                      <div className="card-header card-header-rose text-center">
                        <h4 className="card-title">Forgot Password</h4>                        
                      </div>
                      <div className="card-body">                        
                        <span className="bmd-form-group">
                          <div className="input-group">
                            <div className="input-group-prepend">
                              <span className="input-group-text">
                                <i className="material-icons">email</i>
                              </span>
                            </div>
                            <input
                              type="email"
                              className="form-control"
                              placeholder="Enter your email"
                              value={admin.email}
                              name="email"
                              onChange={(e)=>this._handleOnChange(e)}
                            />
                          </div>
                          {errors && (
                            <div className="login-validation-error">
                              {errors.email}
                            </div>
                            )}
                        </span>                        
                      </div>
                      <div onClick={() => this._backToLogin()} className="btn btn-rose btn-link btn-sm forgot-pwd">
                          Back to login
                        </div>
                      <div className="card-footer justify-content-center">
                        <button
                          type="submit"
                          className="btn btn-fill btn-rose"
                          disabled={loading}
                        >
                        {loading ? (
                            <>
                              <i className="fa fa-spinner fa-spin mr5" />
                              &nbsp;&nbsp;
                            </>
                          ) : null}
                          Reset Password
                        <div className="ripple-container"></div></button>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
            <footer className="footer">
              <div className="container">
                <div className="copyright float-right">&copy; MA13</div>
              </div>
            </footer>
          </div>
        </div>
      </div>
    );
  }
}

export default ForgotPassword;
