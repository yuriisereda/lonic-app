import React, {Component} from "react";
import ImageUploading from "react-images-uploading";
import "./Banner.module.css";
import {getBanner, uploadBanner} from "../../../http/http-calls";
import {ToastsStore} from "react-toasts";

class Banner extends Component {
	state = {
		loading: false,
		imageList: null,
		banner: null,
		originBanner: null,
	};

	componentDidMount() {
		this._getBanner();
	}

	_getBanner() {
		this.setState({loading: true});
		getBanner()
			.then((response) => {
				this.setState({loading: false});
				const banner = JSON.parse(JSON.stringify(response.image_url));
				this.setState({banner: banner, originBanner: banner});
			}, (error) => {
				this.setState({loading: false});
				console.log('error :', error);
			})
	}

	_uploadBanner() {
		this.setState({loading: true});
		const {banner} = this.state;
		const data = {banner_url: banner};

		uploadBanner(data)
			.then((response) => {
				this.setState({loading: false});
				if (banner !== null) {
					this.setState({originBanner: JSON.parse(JSON.stringify(banner))});
				} else {
					this.setState({originBanner: null});
				}
				ToastsStore.success('Banner updated successfully');
				console.log('banner', 'upload banner success');
			}, (error) => {
				this.setState({loading: false});
				ToastsStore.error('Something went wrong!', 1500);
				console.log('error :', error);
			})
	}

	onChange = imageList => {
		this.setState({imageList});
		if (imageList && imageList.length > 0) {
			this.setState({banner: JSON.parse(JSON.stringify(imageList[0].dataURL))});
		}
	};

	onUpload = () => {
		this._uploadBanner();
	}

	render() {
		const {loading, banner, originBanner} = this.state;
		return (
			<>
				{
					loading ? (
						<div className="loading-data">
							<i className="fa fa-spinner fa-spin loader-spinner"/>
							Loading Banner
						</div>
					) : (
						<div className="container">
							<ImageUploading multiple={false} onChange={this.onChange}>
								{({imageList, onImageUpload, onImageRemoveAll}) => (
									<div className="row" style={{justifyContent: 'center'}}>
										<div className="upload__image-wrapper col-md-12">
											<button
												type="button"
												className="btn btn-warning pull-right mr-2"
												disabled={originBanner === banner}
												onClick={this.onUpload}
											>
												&nbsp;Save
											</button>
											<button
												type="button"
												className="btn btn-rose pull-right mr-2"
												onClick={() => {
													onImageRemoveAll();
													this.setState({banner: null, imageList: null});
												}}
											>
												Clear
											</button>
											<button
												type="button"
												className="btn btn-primary pull-right mr-2"
												onClick={onImageUpload}
											>
												Select
											</button>
										</div>
									</div>
								)}
							</ImageUploading>
							<div className="row" style={{marginTop: '25px', justifyContent: 'center'}}>
								{
									banner ?
										<img src={banner} alt=""/>
										: (
											!originBanner ?
												<>There is no banner to display</> :
												null
										)
								}
							</div>
						</div>
					)
				}
			</>
		);
	}
}

export default Banner;
