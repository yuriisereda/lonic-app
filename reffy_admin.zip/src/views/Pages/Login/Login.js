import React, { Component } from "react";
import { ToastsStore } from "react-toasts";
import { login } from "../../../http/http-calls";
class Login extends Component {
  state = {
    admin: {
      email: "",
      password: ""
    },
    errors: {},
    isDirty: {
      email: false,
      password: false
    },
    loading: false
  };

  /**
   * _handleOnChange
   * To handle input on change and set the values to state
   */
  _handleOnChange = ({ currentTarget }) => {
    const { admin, isDirty } = this.state;
    admin[currentTarget.name] = currentTarget.value;
    isDirty[currentTarget.name] = true;
    this.setState({ admin });
    this._validateForm();
  };

  /**
   * To handle submit of the form and validate it
   */
  _handleOnSubmit = event => {
    event.preventDefault();
    const { isDirty } = this.state;
    isDirty.email = true;
    isDirty.password = true;
    this.setState({ isDirty });
    console.log(this.state.isDirty);
    let errors = this._validateForm();
    console.log(errors);
    // this.setState({errors});
    if (!errors) {
      console.log("Make API call");
      this._login();
    }
  };

  /**
   * To Validate the form and show the error messages
   */
  _validateForm() {
    const { admin, errors, isDirty } = this.state;
    // console.log(admin, isDirty);
    Object.keys(admin).forEach(each => {
      if (each === "email" && isDirty.email) {
        if (!admin.email.trim().length) {
          errors.email = "Email is Required";
        } else if (
          admin.email.trim().length &&
          !new RegExp(
            "^[a-zA-Z0-9]{1}[a-zA-Z0-9._+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,3}$"
          ).test(admin.email)
        ) {
          errors.email = "Please enter valid Email";
        } else {
          delete errors[each];
          isDirty.email = false;
        }
      } else if (each === "password" && isDirty.password) {
        if (!admin.password.trim().length) {
          // console.log(admin.password);
          errors[each] = "Password is Required";
        } else {
          delete errors[each];
          isDirty.password = false;
        }
      }
    });
    this.setState({ errors });
    return Object.keys(errors).length ? errors : null;
  }

  /**
   * Make login api call and navigate to dashboard after login
   */
  _login = () => {
    let { admin, loading } = this.state;
    console.log('admin :', admin);
    const data = {
      username: admin.email,
      password: admin.password
    };
    loading = true;
    this.setState({ loading });
    login(data).then(
      response => {
        console.log(response);
        localStorage.ma13AdminToken = response.accessToken;
        loading = false;
        this.setState({ loading });
        ToastsStore.success("Successfully logged in!", 3000);
        this.props.history.push("dashboard/users");
      },
      error => {
        loading = false;
        this.setState({ loading });
        ToastsStore.error(error.message, 1500);
      }
    );
  };

  /**
   * To navigate to Forgot password
   */
  _goToForgotPassword = (e) => {
    e.preventDefault();
    this.props.history.push("forgot-password");
  };

  render() {
    const { admin, errors, loading } = this.state;
    
    return (
      <div>
        <nav className="navbar navbar-expand-lg navbar-transparent navbar-absolute fixed-top text-white">
          <div className="container">
            <div className="navbar-wrapper">
              <a className="navbar-brand" href="#pablo">
                MA13 Logo
              </a>
            </div>
          </div>
        </nav>
        <div className="wrapper wrapper-full-page">
          <div
            className="page-header login-page header-filter login-bg"
            filter-color="black"
          >
            <div className="container">
              <div className="row">
                <div className="col-lg-5 col-md-6 col-sm-8 ml-auto mr-auto">
                  <form className="form" onSubmit={this._handleOnSubmit} noValidate>
                    <div className="card card-login">
                      <div className="card-header card-header-rose text-center">
                        <h4 className="card-title">Admin Panel Login</h4>                        
                      </div>
                      <div className="card-body">                        
                        <span className="bmd-form-group">
                          <div className="input-group">
                            <div className="input-group-prepend">
                              <span className="input-group-text">
                                <i className="material-icons">email</i>
                              </span>
                            </div>                           
                            <input
                              type="email"
                              className="form-control"
                              placeholder="Enter email"
                              value={admin.email}
                              name="email"
                              onChange={(e)=>this._handleOnChange(e)}
                            />                            
                          </div>
                          {errors && (
                            <div className="login-validation-error">
                              {errors.email}
                            </div>
                            )}
                        </span>
                        <span className="bmd-form-group">
                          <div className="input-group">
                            <div className="input-group-prepend">
                              <span className="input-group-text">
                                <i className="material-icons">lock_outline</i>
                              </span>
                            </div>
                            <input
                              type="password"
                              className="form-control"
                              placeholder="Enter password"
                              value={admin.password}
                              name="password"
                              onChange={(e)=>this._handleOnChange(e)}
                            />
                           
                          </div>
                          <a href="javascript.void(0)" onClick={(e)=>this._goToForgotPassword(e)} className="btn btn-rose btn-link btn-sm forgot-pwd">
                          Forgot Password
                        </a>
                        {errors && (
                            <div className="login-validation-error">
                              {errors.password}
                            </div>
                          )}
                        </span>
                      </div>                      
                      <div className="card-footer justify-content-center login-btn-wrap">                        
                        <button type="submit" className="btn btn-fill btn-rose" disabled={loading}
                        >
                          {loading ? (
                            <>
                              <i className="fa fa-spinner fa-spin mr5" />
                              &nbsp;
                            </>
                          ) : null}
                          Login<div className="ripple-container"></div></button>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
            <footer className="footer">
              <div className="container">
                <div className="copyright float-right">&copy; MA13</div>
              </div>
            </footer>
          </div>
        </div>
      </div>
    );
  }
}

export default Login;
