MA13 Admin Panel
================

Install instructions
--------------------

1) npm i
2) Change baseURL inside src/config/index.js [Example:  ]
2) npm run build
3) npm run start:prod

