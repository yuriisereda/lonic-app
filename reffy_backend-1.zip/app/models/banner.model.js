module.exports = (sequelize, Sequelize) => {
    const Banner = sequelize.define("banner", {
        image_url: {
            type: Sequelize.TEXT('long')
        },
        created_time: {
            type: Sequelize.DATE
        },
        created_by: {
            type: Sequelize.INTEGER(11).UNSIGNED
        },
        updated_time: {
            type: Sequelize.DATE
        },
        updated_by: {
            type: Sequelize.INTEGER(11).UNSIGNED
        },
    }, {
        timestamps: false,
        underscored: true,
    });

    return Banner;
};
