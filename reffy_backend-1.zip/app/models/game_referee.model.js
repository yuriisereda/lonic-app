const constants = require("../constants");

module.exports = (sequelize, Sequelize) => {
    const GameReferee = sequelize.define("game_referee", {
        game_id: {
            type: Sequelize.INTEGER(11).UNSIGNED
        },
        user_referee_id: {
            type: Sequelize.INTEGER(11).UNSIGNED
        },
        status: {
            type: Sequelize.ENUM(constants.referee_applied, constants.referee_hired)
        },
        created_time: {
            type: Sequelize.DATE
        },
        created_by: {
            type: Sequelize.INTEGER(11).UNSIGNED
        },
        updated_time: {
            type: Sequelize.DATE
        },
        updated_by: {
            type: Sequelize.INTEGER(11).UNSIGNED
        },
    }, {
        timestamps: false,
        underscored: true,
    });

    return GameReferee;
};
