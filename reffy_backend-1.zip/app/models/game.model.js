const constants = require("../constants");

module.exports = (sequelize, Sequelize) => {
    const Game = sequelize.define("game", {
        user_coach_id: {
            type: Sequelize.INTEGER(11).UNSIGNED
        },
        ground_name: {
            type: Sequelize.STRING
        },
        ground_lat: {
            type: Sequelize.DOUBLE
        },
        ground_lng: {
            type: Sequelize.DOUBLE
        },
        start_time: {
            type: Sequelize.DATE
        },
        opponent: {
            type: Sequelize.STRING
        },
        play_form: {
            type: Sequelize.STRING
        },
        play_time: {
            type: Sequelize.STRING
        },
        game_type: {
            type: Sequelize.STRING
        },
        remuneration: {
            type: Sequelize.STRING
        },
        information: {
            type: Sequelize.TEXT('tiny')
        },
        rating: {
            type: Sequelize.INTEGER(3).UNSIGNED
        },
        status: {
            type: Sequelize.ENUM(
                constants.game_available,
                constants.game_unavailable,
                constants.game_rate_waiting,
                constants.game_closed
            )
        },
        created_time: {
            type: Sequelize.DATE
        },
        created_by: {
            type: Sequelize.INTEGER(11).UNSIGNED
        },
        updated_time: {
            type: Sequelize.DATE
        },
        updated_by: {
            type: Sequelize.INTEGER(11).UNSIGNED
        },
    }, {
        timestamps: false,
        underscored: true,
    });

    return Game;
};
