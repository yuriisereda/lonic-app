const constants = require("../constants");

module.exports = (sequelize, Sequelize) => {
    const User = sequelize.define("user", {
        username: {
            type: Sequelize.STRING
        },
        email: {
            type: Sequelize.STRING
        },
        mobile_phone: {
            type: Sequelize.STRING
        },
        photo_url: {
            type: Sequelize.TEXT('long')
        },
        password: {
            type: Sequelize.STRING
        },
        user_type: {
            type: Sequelize.ENUM(constants.admin, constants.coach, constants.referee)
        },
        coach_club: {
            type: Sequelize.STRING
        },
        coach_club_team: {
            type: Sequelize.STRING
        },
        city_name: {
            type: Sequelize.STRING
        },
        city_lat: {
            type: Sequelize.DOUBLE
        },
        city_lng: {
            type: Sequelize.DOUBLE
        },
        referee_id: {
            type: Sequelize.STRING
        },
        referee_play_form: {
            type: Sequelize.STRING
        },
        created_time: {
            type: Sequelize.DATE
        },
        created_by: {
            type: Sequelize.INTEGER(11).UNSIGNED
        },
        updated_time: {
            type: Sequelize.DATE
        },
        updated_by: {
            type: Sequelize.INTEGER(11).UNSIGNED
        },
    }, {
        timestamps: false,
        underscored: true,
    });

    return User;
};
