// Your One signal App ID: ac5d0a61-77f4-4c17-a914-6ed7ecebe17a
// one signal rest api key: ZjEzMjBlOTUtNTBmYS00MGJjLTg3YmMtNmE1YTM5Mzk3ZmE3
exports.oneSignalAppID = 'ac5d0a61-77f4-4c17-a914-6ed7ecebe17a';
exports.oneSignalRestAPIKey = 'ZjEzMjBlOTUtNTBmYS00MGJjLTg3YmMtNmE1YTM5Mzk3ZmE3';
