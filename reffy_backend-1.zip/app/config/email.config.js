// https://myaccount.google.com/lesssecureapps
exports.mailOptions = {
	from: '',
	subject: 'Welcome to Reffy',
};

exports.transporterOptions = {
	service: 'gmail',
	auth: {
		user: '',
		pass: ''
	}
};