module.exports = {
	secret: "ma13-reffy-secret-key"
};
