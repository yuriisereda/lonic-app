const nodemailer = require("nodemailer");
const transporterOptoins = require("../../config/email.config").transporterOptions;
const mailOptions = require("../../config/email.config").mailOptions;

const config = {
	service: transporterOptoins.service,
	auth: {
		user: transporterOptoins.auth.user,
		pass: transporterOptoins.auth.pass
	}
};

const transporter = nodemailer.createTransport(config);

exports.sendMail = (to, password) => {
	const eMailOptions = {
		from: mailOptions.from,
		to: to,
		subject: mailOptions.subject,
		text: `This is your password: ${password}`
	};

	transporter.sendMail(eMailOptions, function (err, info) {
		if (err) {
			console.log('mail send error: ', err);
		} else {
			console.log('mail sent: ', info.response);
		}
	});
};
