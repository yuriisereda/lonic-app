const mailer = require("../utils/email");
const db = require("../models");
const config = require("../config/auth.config");
const constants = require("../constants")
const User = db.user;
const validateRegisterInput = require("../validations/register.validation");
const Op = db.Sequelize.Op;

const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");

const generatePassword = length => {
	let result = '';
	const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
	const charactersLength = characters.length;
	for (let i = 0; i < length; i++) {
		result += characters.charAt(Math.floor(Math.random() * charactersLength));
	}
	return result;
};

exports.register = (req, res) => {
	const {errors, isValid} = validateRegisterInput(req.body);
	if (!isValid) {
		return res.status(400).json({
			message: 'validation failed'
		});
	}

	const password = generatePassword(3);

	const common_info = {
		username: req.body.username,
		email: req.body.email,
		password: bcrypt.hashSync(password, 8),
		mobile_phone: req.body.mobile_phone,
		photo_url: req.body.photo_url,
		user_type: req.body.user_type,
		city_name: req.body.city_name,
		city_lat: req.body.city_lat,
		city_lng: req.body.city_lng,
		created_time: new Date(),
		updated_time: new Date(),
	};
	const coach_info = {
		coach_club: req.body.coach_club,
		coach_club_team: req.body.coach_club_team,
	};
	const referee_info = {
		referee_id: req.body.referee_id,
		referee_play_form: req.body.referee_play_form,
	};
	const new_user = {
		...common_info,
		...coach_info,
		...referee_info,
	};
	// Save User to Database
	User.create(new_user)
		.then(user => {
			mailer.sendMail(new_user.email, password);
			return res.status(200).send({message: "User registered successfully!", user: user});
		})
		.catch(err => {
			return res.status(500).send({message: err.message});
		});
};

exports.login = (req, res) => {
	User.findOne({
		where: {
			[Op.and]: [
				{
					[Op.or]: [
						{username: req.body.username},
						{email: req.body.username}
					]
				},
				{
					[Op.or]: [
						{user_type: constants.referee},
						{user_type: constants.coach}
					]
				}
			]
		}
	})
		.then(user => {
			if (!user) {
				return res.status(404).send({message: "User Not found."});
			}

			const passwordIsValid = bcrypt.compareSync(
				req.body.password,
				user.password
			);

			if (!passwordIsValid) {
				return res.status(404).send({
					accessToken: null,
					message: "Invalid Password!"
				});
			}

			const token = jwt.sign({id: user.id}, config.secret, {
				expiresIn: 86400 * 365 // 24 hours
			});

			return res.status(200).send({
				id: user.id,
				username: user.username,
				email: user.email,
				user_type: user.user_type,
				referee_play_form: user.referee_play_form,
				accessToken: token
			});
		})
		.catch(err => {
			return res.status(500).send({message: err.message});
		});
};

exports.adminLogin = (req, res) => {
	User.findOne({
		where: {
			[Op.or]: [
				{username: req.body.username},
				{email: req.body.username}
			],
			user_type: constants.admin
		}
	})
		.then(admin => {
			if (!admin) {
				return res.status(404).send({message: "Admin Not found."});
			}

			const passwordIsValid = bcrypt.compareSync(
				req.body.password,
				admin.password
			);

			if (!passwordIsValid) {
				return res.status(404).send({
					accessToken: null,
					message: "Invalid Password!"
				});
			}

			const token = jwt.sign({id: admin.id}, config.secret, {
				expiresIn: 86400 * 365 // 24 hours
			});

			return res.status(200).send({
				id: admin.id,
				username: admin.username,
				email: admin.email,
				user_type: admin.user_type,
				accessToken: token
			});
		})
		.catch(err => {
			return res.status(500).send({message: err.message});
		});
};

exports.recoverPassword = async (req, res) => {
	try {
		const user = await User.findOne({
			where: {
				[Op.or]: [
					{username: req.body.username},
					{email: req.body.username}
				],
			}
		});

		if (!user) {
			return res.status(404).send({message: "User not found"});
		}

		const new_password = generatePassword(3);

		user.password = bcrypt.hashSync(new_password, 8);
		await user.save();

		mailer.sendMail(user.email, new_password);
		return res.send({message: "Password recovered successfully!"});
	} catch (err) {
		return res.status(500).send({message: err.message});
	}
};
