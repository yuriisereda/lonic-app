const db = require("../models");
const moment = require("moment");
const constants = require("../constants");
const Game = db.game;
const GameReferee = db.game_referee;
const validateCreateGameInput = require("../validations/game.validation");
const oneSignaler = require("../utils/one-signal");

newGame = (req, res) => {
	const {errors, isValid} = validateCreateGameInput(req.body);
	if (!isValid) {
		return res.status(400).json(errors);
	}

	let new_game = {user_coach_id: req.user_id};

	const keys = Object.keys(req.body);
	for (let i = 0; i < keys.length; i++) {
		new_game[keys[i]] = req.body[keys[i]];
	}
	// timestamp
	new_game.status = constants.game_available;
	new_game.created_time = moment().format();
	new_game.created_by = req.user_id;
	new_game.updated_time = moment().format();
	new_game.updated_by = req.user_id;

	Game.create(new_game)
		.then(game => {
			return res.status(200).send(game);
		})
		.catch(err => {
			return res.status(500).send({message: err.message});
		});
};

loadGames = async (req, res) => {
	const user_id = req.body.user_id;
	try {
		const games = await Game.findAll({
			attributes: [
				'id',
				'ground_name',
				'start_time',
				'play_form',
			],
			include: [
				{
					association: 'coach',
					attributes: [
						'id',
						'username'
					]
				},
				{
					association: 'referees',
					attributes: [
						'id',
						'status'
					],
					include: [
						{
							association: 'user',
							attributes: [
								'id',
								'username'
							]
						}]
				}
			]
		});

		return res.status(200).send(games);
	} catch (err) {
		return res.status(500).send({message: err.message});
	}
};

loadGame = async (req, res) => {
	const game_id = req.query.game_id;
	try {
		const game = await Game.findOne({
			where: {
				id: game_id
			},
			attributes: [
				'id',
				'ground_name',
				'ground_lat',
				'ground_lng',
				'opponent',
				'play_time',
				'start_time',
				'play_form',
				'game_type',
				'remuneration',
				'information',
				'rating',
				'status',
			],
			include: [
				{
					association: 'coach',
					attributes: [
						'id',
						'username',
						'mobile_phone',
						'photo_url',
						'coach_club',
						'coach_club_team',
						'city_name'
					]
				},
				{
					association: 'referees',
					attributes: [
						'id',
						'status'
					],
					include: [
						{
							association: 'user',
							attributes: [
								'id',
								'username',
								'photo_url',
								'mobile_phone',
							]
						}]
				}
			]
		});

		if (game) {
			return res.status(200).send(game);
		} else {
			return res.status(400).send({message: 'Game not exist!'});
		}
	} catch (err) {
		return res.status(500).send({message: err.message});
	}
};

hireReferee = async (req, res) => {
	const game_id = req.body.game_id;
	const referee_id = req.body.referee_id;

	try {
		const created_game_referee = await GameReferee.findOne({
			where: {
				game_id: game_id,
				user_referee_id: referee_id
			}
		});

		if (created_game_referee) { // when hire highlighted referee, convert game referee status to hired
			created_game_referee.status = constants.referee_hired;
			created_game_referee.updated_by = req.user_id;
			created_game_referee.updated_time = moment().format();
			await created_game_referee.save();
		} else {
			const new_game_referee = {
				game_id: game_id,
				user_referee_id: referee_id,
				status: constants.referee_hired,
				created_time: moment().format(),
				created_by: req.user_id,
				updated_time: moment().format(),
				updated_by: req.user_id
			};
			const game_referee = await GameReferee.create(new_game_referee);

			if (!game_referee) {
				return res.status(500).send({message: "Game referee hiring failed"});
			}
		}
		/*
		*  convert game status to rate_waiting
		* */
		const game = await Game.findOne({
			where: {
				id: game_id
			}
		});

		if (!game) {
			return res.status(404).send({message: "Game Not found."});
		}
		game.status = constants.game_rate_waiting;
		await game.save();
		return res.status(200).send({message: "Game referee hired successfully!"});
	} catch (err) {
		return res.status(500).send({message: err.message});
	}
};

applyGameAsReferee = async (req, res) => {
	const game_id = req.body.game_id;
	const referee_id = req.user_id;

	const game = await Game.findOne({
		where: {
			id: game_id
		}
	});

	if (!game) {
		return res.status(404).send({message: "Game Not found."});
	}

	const coach_id = game.user_coach_id;

	const new_game_referee = {
		game_id: game_id,
		user_referee_id: referee_id,
		status: constants.referee_applied,
		created_time: moment().format(),
		created_by: referee_id,
		updated_time: moment().format(),
		updated_by: referee_id
	};

	GameReferee.create(new_game_referee)
		.then(game_referee => {
			console.log('coach id: ', coach_id);
			oneSignaler.sendNotification(coach_id);
			return res.status(200).send({message: "Game referee applied successfully!"});
		})
		.catch(err => {
			return res.status(500).send({message: err.message});
		});
};

rateGame = async (req, res) => {
	const referee_id = req.user_id;
	const game_id = req.body.game_id;
	const rate = req.body.rate;

	try {
		const game = await Game.findOne({
			where: {
				id: game_id
			}
		});

		if (!game) {
			return res.status(404).send({message: "Game Not found."});
		}

		game.status = constants.game_closed;
		game.rating = rate;
		game.updated_by = referee_id;
		game.updated_time = moment().format();


		await game.save();
		return res.status(200).send({message: "Game rated successfully!"});
	} catch (err) {
		return res.status(500).send({message: err.message});
	}

};

const controller = {
	newGame,
	loadGames,
	loadGame,
	hireReferee,
	applyGameAsReferee,
	rateGame
};

module.exports = controller;
