const bcrypt = require("bcryptjs");
const db = require("../models");
const User = db.user;

getAllUsers = (req, res) => {
	User.findAll().then(users => {
		return res.status(200).send({users: users});
	}).catch(err => {
		return res.status(500).send({message: err.message});
	});
};

getUserById = (req, res) => {
	const user_id = req.query.user_id;
	User.findOne({
		where: {
			id: user_id
		}
	}).then(user => {
		if (!user) {
			return res.status(404).send({message: "User Not found."});
		}

		return res.status(200).send(user);
	}).catch(err => {
		return res.status(500).send({message: err.message});
	});
};

deleteUserById = (req, res) => {
	const user_id = req.query.user_id;
	User.destroy({
		where: {id: user_id}
	}).then(cnt => {
		return res.status(200).send({
			deleted_count: cnt
		});
	}).catch(err => {
		return res.status(500).send({message: err.message});
	})
};

updateUserById = async (req, res) => {
	const user_id = req.body.id;

	try {
		const user = await User.findOne({
			where: {
				id: user_id
			}
		});

		if (!user) {
			return res.status(404).send({message: "User Not found."});
		}

		const keys = Object.keys(req.body);
		for (let i = 0; i < keys.length; i++) {
			if (keys[i] !== 'id') {
				user[keys[i]] = req.body[keys[i]];
			}
		}

		await user.save();
		return res.status(200).send(user);
	} catch (err) {
		return res.status(500).send({message: err.message});
	}
};

const controller = {
	getAllUsers,
	getUserById,
	deleteUserById,
	updateUserById,
};

module.exports = controller;
