const db = require("../models");
const Banner = db.banner;

loadBanner = (req, res) => {
	Banner.findOne().then(banner => {
		if (!banner) {
			return res.status(404).send({message: 'banner not exist'});
		} else {
			return res.status(200).send(banner);
		}
	}).catch(err => {
		return res.status(500).send({message: err.message});
	});
};

deleteBanner = (req, res) => {
	Banner.findOne().then(banner => {
		if (!banner) {
			return res.status(400).send({message: `Banner doesn't exist`});
		}

		Banner.destroy({
			where: {id: banner.id}
		}).then(cnt => {
			return res.status(200).send({message: `Banner deleted successfully!`});
		}).catch(err => {
			return res.status(500).send({message: err.message});
		})
	}).catch(err => {
		return res.status(500).send({message: err.message});
	})
};

uploadBanner = async (req, res) => {
	const user_id = req.user_id;

	try {
		const banner = await Banner.findOne();

		if (!banner) {
			const banner_url = req.body.banner_url;
			const new_banner = {
				image_url: banner_url,
				created_time: new Date(),
				created_by: user_id,
				updated_time: new Date(),
				updated_by: user_id,
			};

			try {
				await Banner.create(new_banner);
				return res.status(200).send(new_banner);
			} catch (e) {
				return res.status(500).send({message: e.message});
			}
		} else {
			banner.image_url = req.body.banner_url;
			banner.updated_time = new Date();
			banner.updated_by = user_id;

			try {
				await banner.save();
				return res.status(200).send(banner);
			} catch (e) {
				return res.status(500).send({message: e.message});
			}
		}
	} catch (err) {
		return res.status(500).send({message: err.message});
	}
};

const controller = {
	uploadBanner,
	loadBanner,
	deleteBanner,
};

module.exports = controller;
