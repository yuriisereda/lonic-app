const {authJwt} = require("../middleware");
const controller = require("../controllers/game.controller");

module.exports = function (app) {
	app.use(function (req, res, next) {
		res.header(
			"Access-Control-Allow-Headers",
			"x-access-token, Origin, Content-Type, Accept"
		);
		next();
	});

	app.post(
		"/game_new",
		[
			authJwt.verifyToken,
			authJwt.isCoach,
		],
		controller.newGame
	);

	app.post(
		"/games_load",
		[authJwt.verifyToken],
		controller.loadGames
	);

	app.get(
		"/game_load",
		[authJwt.verifyToken],
		controller.loadGame
	)

	app.post(
		"/game_hire_referee",
		[
			authJwt.verifyToken,
			authJwt.isCoach
		],
		controller.hireReferee
	);

	app.post(
		"/game_apply_as_referee",
		[
			authJwt.verifyToken,
			authJwt.isReferee
		],
		controller.applyGameAsReferee
	);

	app.post(
		"/game_rate",
		[
			authJwt.verifyToken,
			authJwt.isReferee
		],
		controller.rateGame
	);
};
