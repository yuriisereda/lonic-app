const Validator = require("validator");
const isEmpty = require("is-empty");

module.exports = function validateCreateGameInput(data) {
	let errors = {};
	// Convert empty fields to an empty string so we can use validator functions
	data.ground_name = !isEmpty(data.ground_name) ? data.ground_name : "";
	data.start_time = !isEmpty(data.start_time) ? data.start_time : "";
	data.opponent = !isEmpty(data.opponent) ? data.opponent : "";
	data.play_form = !isEmpty(data.play_form) ? data.play_form : "";
	data.play_time = !isEmpty(data.play_time) ? data.play_time : "";
	data.game_type = !isEmpty(data.game_type) ? data.game_type : "";
	data.remuneration = !isEmpty(data.remuneration) ? data.remuneration : "";
	data.information = !isEmpty(data.information) ? data.information : "";

	// Ground name checks
	if (Validator.isEmpty(data.ground_name)) {
		errors.ground_name = "Ground name field is required";
	}
	// Start time checks
	if (Validator.isEmpty(data.start_time)) {
		errors.start_time = "Start time field is required";
	}
	// Opponent checks
	if (Validator.isEmpty(data.opponent)) {
		errors.opponent = "Opponent field is required";
	}
	// Play form checks
	if (Validator.isEmpty(data.play_form)) {
		errors.play_form = "Play form field is required";
	}
	// Play time checks
	if (Validator.isEmpty(data.play_time)) {
		errors.play_time = "Play time field is required";
	}
	// Game_type checks
	if (Validator.isEmpty(data.game_type)) {
		errors.game_type = "Game type field is required";
	}
	// Remuneration checks
	if (Validator.isEmpty(data.remuneration)) {
		errors.remuneration = "Remuneration field is required";
	}
	// Information checks
	if (Validator.isEmpty(data.information)) {
		errors.information = "Information field is required";
	}

	return {
		errors,
		isValid: isEmpty(errors)
	};
};
