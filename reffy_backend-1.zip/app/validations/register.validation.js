const Validator = require("validator");
const isEmpty = require("is-empty");
const validatePhoneNumber = require("validate-phone-number-node-js");
const isUrl = require("is-url");
const constants = require("../constants");

module.exports = function validateRegisterInput(data) {
	let errors = {};
	// Convert empty fields to an empty string so we can use validator functions
	// Common
	data.username = !isEmpty(data.username) ? data.username : "";
	data.email = !isEmpty(data.email) ? data.email : "";
	data.mobile_phone = !isEmpty(data.mobile_phone) ? data.mobile_phone : "";
	data.photo_url = !isEmpty(data.photo_url) ? data.photo_url : "";
	data.user_type = !isEmpty(data.user_type) ? data.user_type : "";
	data.city_name = !isEmpty(data.city_name) ? data.city_name : "";
	data.city_lat = !isEmpty(data.city_lat) ? data.city_lat : "";
	data.city_lng = !isEmpty(data.city_lng) ? data.city_lng : "";
	// Only for coach
	data.coach_club = !isEmpty(data.coach_club) ? data.coach_club : "";
	data.coach_club_team = !isEmpty(data.coach_club_team) ? data.coach_club_team : "";
	// Only for referee
	data.referee_id = !isEmpty(data.referee_id) ? data.referee_id : "";
	data.referee_play_form = !isEmpty(data.referee_play_form) ? data.referee_play_form : "";

	// Name checks
	if (Validator.isEmpty(data.username)) {
		errors.username = "Name field is required";
	} else if (Validator.isEmail(data.username)) {
		errors.username = "Name is not validate";
	}
	// Email checks
	if (Validator.isEmpty(data.email)) {
		errors.email = "Email field is required";
	} else if (!Validator.isEmail(data.email)) {
		errors.email = "Email is invalid";
	}
	// Phone number checks
	/*if (!validatePhoneNumber.validate(data.mobile_phone)) {
			errors.mobile_phone = "Phone number is not validate";
	}*/
	// Photo url checks
	/*if (!isUrl(data.photo_url)) {
			errors.photo_url = "Photo url is not validate";
	}*/
	// User type checks
	const role_index = constants.ROLES.indexOf(data.user_type);
	if (role_index === -1) {
		errors.user_type = "User type is not validate";
	} else {
		if (data.user_type === constants.coach) { // when user_type is coach
			if (Validator.isEmpty(data.coach_club)) {
				errors.coach_club = "Coach club is required";
			}
			if (Validator.isEmpty(data.coach_club_team)) {
				errors.coach_club_team = "Coach club team is required";
			}
		} else if (data.user_type === constants.referee) { // when user_type is referee
			if (Validator.isEmpty(data.referee_id)) {
				errors.referee_id = "Referee id is required";
			}
			if (Validator.isEmpty(data.referee_play_form)) {
				errors.referee_play_form = "Referee play form is required";
			}
		}
	}

	return {
		errors,
		isValid: isEmpty(errors)
	};
};
