const jwt = require("jsonwebtoken");
const config = require("../config/auth.config.js");
const db = require("../models");
const constants = require("../constants");
const User = db.user;

verifyToken = (req, res, next) => {
  let token = req.headers["x-access-token"];

  if (!token) {
    return res.status(401).send({
      message: "No token provided!"
    });
  }

  jwt.verify(token, config.secret, (err, decoded) => {
    if (err) {
      return res.status(401).send({
        message: "Unauthorized!"
      });
    }
    req.user_id = decoded.id;
    next();
  });
};

isAdmin = (req, res, next) => {
  User.findByPk(req.user_id).then(user => {
    if (user.user_type === constants.admin) {
      next();
    } else {
      res.status(403).send({
        message: "Require Admin Role!"
      });
      return;
    }
  });
};

isCoach = (req, res, next) => {
  User.findByPk(req.user_id).then(user => {
    if (user.user_type === constants.coach) {
      next();
    } else {
      res.status(403).send({
        message: "Require Coach Role!"
      });
      return;
    }
  });
};

isReferee = (req, res, next) => {
  User.findByPk(req.user_id).then(user => {
    if (user.user_type === constants.referee) {
      next();
    } else {
      res.status(403).send({
        message: "Require Referee Role!"
      });
      return;
    }
  });
};

const authJwt = {
  verifyToken: verifyToken,
  isAdmin: isAdmin,
  isCoach: isCoach,
  isReferee: isReferee
};
module.exports = authJwt;
