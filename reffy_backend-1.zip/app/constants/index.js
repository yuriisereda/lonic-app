const constants = {};

constants.admin = "admin";
constants.coach = "coach";
constants.referee = "referee";
constants.ROLES = [constants.admin, constants.coach, constants.referee];
constants.referee_applied = "applied";
constants.referee_hired = "hired";
constants.game_available = 'available';
constants.game_unavailable = 'unavailable';
constants.game_rate_waiting = 'rate_waiting';
constants.game_closed = 'closed';

module.exports = constants;
