const express = require("express");
const bodyParser = require("body-parser");
const app = express();
const cors = require("cors");
// cors policy
const corsOptions = {
	"origin": "*",
	"methods": "GET,HEAD,PUT,PATCH,POST,DELETE"
};

app.use(cors(corsOptions));

// parse requests of content-type - application/json
app.use(bodyParser.json({limit: '10mb'}));

// parse requests of content-type - application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({limit: '10mb', extended: false}));

// database model
const db = require("./app/models");

db.sequelize.sync().then(res => {
	db.game.hasMany(db.game_referee, {as: 'referees', foreignKey: 'game_id', sourceKey: 'id'});
	db.game.hasOne(db.user, {as: 'coach', foreignKey: 'id', sourceKey: 'user_coach_id'});
	db.game_referee.hasOne(db.user, {as: 'user', foreignKey: 'id', sourceKey: 'user_referee_id'});
	db.sequelize.sync();
});

// this is router for test
app.get("/", (req, res) => {
	res.json({message: "Welcome to reffy app"});
});

// routes
require('./app/routes/auth.routes')(app);
require('./app/routes/user.routes')(app);
require('./app/routes/game.routes')(app);
require('./app/routes/banner.routes')(app);

// set port, listen for requests
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
	console.log(`Server is running on port ${PORT}.`);
});
