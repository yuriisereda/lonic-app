# Reffy backend – JWT Authentication & Authorization with JSONWebToken & Sequelize

## Project setup
```
npm install
```

### Run
```
npm start
```
